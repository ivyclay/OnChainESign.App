"use client";

import { Pen, Calendar, Type, Hash, X, GripVertical } from 'lucide-react';
import type { FieldData } from '@/lib/types';

interface FieldOverlayProps {
  field: FieldData;
  isAdmin?: boolean;
  isActive?: boolean;
  onClick?: () => void;
  onRemove?: () => void;
}

const FIELD_COLORS: Record<string, { bg: string; border: string; icon: React.ReactNode; label: string }> = {
  signature: { bg: 'bg-blue-100/80', border: 'border-blue-400', icon: <Pen className="w-3 h-3" />, label: 'Signature' },
  date:      { bg: 'bg-green-100/80', border: 'border-green-400', icon: <Calendar className="w-3 h-3" />, label: 'Date' },
  initials:  { bg: 'bg-purple-100/80', border: 'border-purple-400', icon: <Hash className="w-3 h-3" />, label: 'Initials' },
  text:      { bg: 'bg-amber-100/80', border: 'border-amber-400', icon: <Type className="w-3 h-3" />, label: 'Text' },
};

export function FieldOverlay({ field, isAdmin, isActive, onClick, onRemove }: FieldOverlayProps) {
  const style = FIELD_COLORS[field.fieldType] || FIELD_COLORS.text;

  return (
    <div
      className={`absolute ${style.bg} ${style.border} border-2 rounded-md flex items-center justify-center cursor-pointer transition-all
        ${isActive ? 'ring-2 ring-offset-1 ring-blue-500 shadow-lg z-20' : 'z-10'}
        ${field.value ? 'border-solid' : 'border-dashed'}
        hover:shadow-md`}
      style={{
        left: `${field.xPercent}%`,
        top: `${field.yPercent}%`,
        width: `${field.widthPercent}%`,
        height: `${field.heightPercent}%`,
        pointerEvents: 'auto',
      }}
      onClick={(e) => { e.stopPropagation(); onClick?.(); }}
    >
      {field.value ? (
        field.fieldType === 'signature' || field.fieldType === 'initials' ? (
          <img src={field.value} alt={field.fieldType} className="w-full h-full object-contain p-0.5" />
        ) : (
          <span className="text-xs font-medium text-gray-800 px-1 truncate">{field.value}</span>
        )
      ) : (
        <div className="flex items-center gap-1 text-xs text-gray-500">
          {style.icon}
          <span className="hidden sm:inline">{field.label || style.label}</span>
        </div>
      )}

      {isAdmin && onRemove && (
        <button
          className="absolute -top-2 -right-2 w-5 h-5 bg-red-500 text-white rounded-full flex items-center justify-center hover:bg-red-600 z-30"
          onClick={(e) => { e.stopPropagation(); onRemove(); }}
        >
          <X className="w-3 h-3" />
        </button>
      )}

      {isAdmin && (
        <div className="absolute -left-1 top-1/2 -translate-y-1/2 text-gray-400">
          <GripVertical className="w-3 h-3" />
        </div>
      )}
    </div>
  );
}
