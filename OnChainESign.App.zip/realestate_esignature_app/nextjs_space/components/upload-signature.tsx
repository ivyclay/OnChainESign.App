"use client";

import { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Upload, X, Image as ImageIcon } from 'lucide-react';

interface UploadSignatureProps {
  onSignatureChange: (signatureData: string) => void;
}

export function UploadSignature({ onSignatureChange }: UploadSignatureProps) {
  const [preview, setPreview] = useState<string>('');
  const [fileName, setFileName] = useState<string>('');
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e?.target?.files?.[0];
    if (!file) return;

    const validTypes = ['image/png', 'image/jpeg', 'image/jpg', 'image/gif', 'image/webp'];
    if (!validTypes?.includes?.(file?.type ?? '')) {
      alert('Please upload a valid image file (PNG, JPEG, GIF, or WebP)');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event?.target?.result as string ?? '';
      setPreview(dataUrl);
      setFileName(file?.name ?? '');
      onSignatureChange?.(dataUrl);
    };
    reader?.readAsDataURL?.(file);
  };

  const handleClear = () => {
    setPreview('');
    setFileName('');
    onSignatureChange?.('');
    if (inputRef?.current) {
      inputRef.current.value = '';
    }
  };

  return (
    <div className="space-y-4">
      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        onChange={handleFileChange}
        className="hidden"
        id="signature-upload"
      />
      
      {!preview ? (
        <label
          htmlFor="signature-upload"
          className="flex flex-col items-center justify-center w-full h-48 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100 transition-colors"
        >
          <div className="flex flex-col items-center justify-center pt-5 pb-6">
            <Upload className="w-10 h-10 text-gray-400 mb-3" />
            <p className="mb-2 text-sm text-gray-500">
              <span className="font-semibold">Click to upload</span> or drag and drop
            </p>
            <p className="text-xs text-gray-400">PNG, JPG, GIF or WebP (max 5MB)</p>
          </div>
        </label>
      ) : (
        <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 bg-white">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2 text-sm text-gray-600">
              <ImageIcon className="w-4 h-4" />
              <span className="truncate max-w-[200px]">{fileName}</span>
            </div>
            <Button type="button" variant="ghost" size="sm" onClick={handleClear}>
              <X className="w-4 h-4" />
            </Button>
          </div>
          <div className="flex items-center justify-center bg-gray-50 rounded-lg p-4">
            <img
              src={preview}
              alt="Uploaded signature"
              className="max-h-32 max-w-full object-contain"
            />
          </div>
        </div>
      )}
    </div>
  );
}
