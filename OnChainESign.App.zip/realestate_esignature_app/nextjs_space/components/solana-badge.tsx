export function SolanaBadge({ className = '' }: { className?: string }) {
  return (
    <div className={`flex items-center gap-1.5 ${className}`}>
      <span className="text-xs text-gray-500">Powered by</span>
      <img src="/solana-logo.png" alt="Powered by Solana" className="h-4 w-4" />
      <span className="text-xs font-semibold bg-gradient-to-r from-[#9945FF] to-[#14F195] bg-clip-text text-transparent">
        Solana
      </span>
    </div>
  );
}
