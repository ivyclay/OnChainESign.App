"use client";

import { useEffect, useRef, useState, useCallback } from 'react';
import { ChevronLeft, ChevronRight, ZoomIn, ZoomOut, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface PdfViewerProps {
  url: string;
  currentPage: number;
  onPageChange: (page: number) => void;
  onTotalPagesChange?: (total: number) => void;
  onPageClick?: (xPercent: number, yPercent: number) => void;
  children?: React.ReactNode;
}

export function PdfViewer({ url, currentPage, onPageChange, onTotalPagesChange, onPageClick, children }: PdfViewerProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [totalPages, setTotalPages] = useState(0);
  const [scale, setScale] = useState(1.2);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState('');
  const [pdfDoc, setPdfDoc] = useState<any>(null);
  const [pageDimensions, setPageDimensions] = useState({ width: 0, height: 0 });

  // Load PDF document
  useEffect(() => {
    let cancelled = false;
    const loadPdf = async () => {
      try {
        setLoading(true);
        setLoadError('');
        const pdfjsLib = await import('pdfjs-dist');
        pdfjsLib.GlobalWorkerOptions.workerSrc = '/pdf.worker.min.mjs';
        const loadingTask = pdfjsLib.getDocument({ url, withCredentials: false });
        const doc = await loadingTask.promise;
        if (cancelled) return;
        setPdfDoc(doc);
        setTotalPages(doc.numPages);
        onTotalPagesChange?.(doc.numPages);
      } catch (err: any) {
        console.error('PDF load error:', err);
        if (!cancelled) {
          setLoadError(err?.message || 'Failed to load PDF document');
          setLoading(false);
        }
      }
    };
    if (url) {
      loadPdf();
    } else {
      setLoading(false);
      setLoadError('No document URL available');
    }
    return () => { cancelled = true; };
  }, [url]);

  // Render current page
  useEffect(() => {
    if (!pdfDoc || !canvasRef.current) return;
    let cancelled = false;
    const renderPage = async () => {
      try {
        setLoading(true);
        const page = await pdfDoc.getPage(currentPage);
        if (cancelled) return;
        const viewport = page.getViewport({ scale });
        const canvas = canvasRef.current;
        if (!canvas) return;
        canvas.width = viewport.width;
        canvas.height = viewport.height;
        setPageDimensions({ width: viewport.width, height: viewport.height });
        const ctx = canvas.getContext('2d');
        if (!ctx) return;
        await page.render({ canvasContext: ctx, viewport }).promise;
        if (!cancelled) setLoading(false);
      } catch (err: any) {
        console.error('Page render error:', err);
        if (!cancelled) {
          setLoadError(err?.message || 'Failed to render page');
          setLoading(false);
        }
      }
    };
    renderPage();
    return () => { cancelled = true; };
  }, [pdfDoc, currentPage, scale]);

  const handleCanvasClick = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
    if (!onPageClick || !containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    onPageClick(x, y);
  }, [onPageClick]);

  return (
    <div className="flex flex-col items-center">
      {/* Controls */}
      <div className="flex items-center gap-3 mb-3 bg-gray-100 rounded-lg px-4 py-2">
        <Button size="sm" variant="ghost" onClick={() => onPageChange(Math.max(1, currentPage - 1))} disabled={currentPage <= 1}>
          <ChevronLeft className="w-4 h-4" />
        </Button>
        <span className="text-sm font-medium min-w-[80px] text-center">
          Page {currentPage} / {totalPages || '...'}
        </span>
        <Button size="sm" variant="ghost" onClick={() => onPageChange(Math.min(totalPages, currentPage + 1))} disabled={currentPage >= totalPages}>
          <ChevronRight className="w-4 h-4" />
        </Button>
        <div className="w-px h-6 bg-gray-300 mx-1" />
        <Button size="sm" variant="ghost" onClick={() => setScale(s => Math.max(0.5, s - 0.2))}>
          <ZoomOut className="w-4 h-4" />
        </Button>
        <span className="text-xs min-w-[40px] text-center">{Math.round(scale * 100)}%</span>
        <Button size="sm" variant="ghost" onClick={() => setScale(s => Math.min(2.5, s + 0.2))}>
          <ZoomIn className="w-4 h-4" />
        </Button>
      </div>

      {/* PDF Canvas with overlay */}
      <div
        ref={containerRef}
        className="relative border-2 border-gray-200 rounded-lg overflow-hidden bg-white shadow-inner"
        style={{ width: pageDimensions.width || '100%', minHeight: pageDimensions.height || 400, height: pageDimensions.height || 'auto' }}
        onClick={handleCanvasClick}
      >
        {loading && !loadError && (
          <div className="absolute inset-0 flex items-center justify-center bg-gray-50 z-10">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#9945FF]" />
          </div>
        )}
        {loadError && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-gray-50 z-10 p-6">
            <AlertCircle className="w-10 h-10 text-red-400 mb-3" />
            <p className="text-sm text-red-600 text-center mb-2">Failed to load PDF</p>
            <p className="text-xs text-gray-500 text-center max-w-xs">{loadError}</p>
          </div>
        )}
        <canvas ref={canvasRef} className="block" />
        {/* Overlay for fields */}
        {pageDimensions.width > 0 && (
          <div className="absolute inset-0" style={{ pointerEvents: onPageClick ? 'none' : 'auto' }}>
            {children}
          </div>
        )}
      </div>
    </div>
  );
}
