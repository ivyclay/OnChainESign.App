"use client";

import { useState, useEffect, useRef } from 'react';
import { Input } from '@/components/ui/input';

interface TypedSignatureProps {
  onSignatureChange: (signatureData: string) => void;
  initialName?: string;
}

const SIGNATURE_FONTS = [
  { name: 'Cursive', style: "'Dancing Script', cursive" },
  { name: 'Elegant', style: "'Great Vibes', cursive" },
  { name: 'Classic', style: "'Pacifico', cursive" },
];

export function TypedSignature({ onSignatureChange, initialName = '' }: TypedSignatureProps) {
  const [name, setName] = useState(initialName ?? '');
  const [selectedFont, setSelectedFont] = useState(0);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (!name) {
      onSignatureChange?.('');
      return;
    }

    const canvas = canvasRef?.current;
    if (!canvas) return;

    const ctx = canvas?.getContext?.('2d');
    if (!ctx) return;

    ctx?.clearRect?.(0, 0, canvas?.width ?? 0, canvas?.height ?? 0);
    ctx.font = `48px ${SIGNATURE_FONTS?.[selectedFont]?.style ?? 'cursive'}`;
    ctx.fillStyle = '#9945FF';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx?.fillText?.(name ?? '', (canvas?.width ?? 500) / 2, (canvas?.height ?? 100) / 2);

    const dataUrl = canvas?.toDataURL?.('image/png') ?? '';
    onSignatureChange?.(dataUrl);
  }, [name, selectedFont, onSignatureChange]);

  return (
    <div className="space-y-4">
      <link
        href="https://fonts.googleapis.com/css2?family=Dancing+Script:wght@700&family=Great+Vibes&family=Pacifico&display=swap"
        rel="stylesheet"
      />
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Type your name:</label>
        <Input
          type="text"
          value={name}
          onChange={(e) => setName(e?.target?.value ?? '')}
          placeholder="Enter your full name"
          className="max-w-md"
        />
      </div>
      
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Select font style:</label>
        <div className="flex flex-wrap gap-2">
          {SIGNATURE_FONTS?.map?.((font, index) => (
            <button
              key={index}
              type="button"
              onClick={() => setSelectedFont(index)}
              className={`px-4 py-2 rounded-md border transition-all ${
                selectedFont === index
                  ? 'border-[#9945FF] bg-[#9945FF]/10 text-[#9945FF]'
                  : 'border-gray-200 hover:border-gray-300'
              }`}
              style={{ fontFamily: font?.style ?? 'cursive' }}
            >
              {font?.name ?? 'Font'}
            </button>
          )) ?? null}
        </div>
      </div>

      {name && (
        <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 bg-white">
          <p className="text-xs text-gray-500 mb-2">Signature preview:</p>
          <div
            className="text-4xl text-[#9945FF] text-center py-4"
            style={{ fontFamily: SIGNATURE_FONTS?.[selectedFont]?.style ?? 'cursive' }}
          >
            {name}
          </div>
        </div>
      )}

      <canvas ref={canvasRef} width={500} height={100} className="hidden" />
    </div>
  );
}
