"use client";

import { useSession } from 'next-auth/react';
import { FileSignature } from 'lucide-react';
import Link from 'next/link';
import { useState } from 'react';

export function HomeHeader() {
  const { data: session, status } = useSession() || {};
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <header className="bg-[#0B0E17]/95 backdrop-blur-xl border-b border-white/5 text-white py-4 px-6 sticky top-0 z-50">
      <div className="max-w-6xl mx-auto flex items-center justify-between">
        <div className="flex items-center gap-3">
          <FileSignature className="w-8 h-8 text-[#9945FF]" />
          <div>
            <h1 className="text-xl font-bold">OnChainESign</h1>
            <div className="hidden sm:flex items-center gap-2">
              <p className="text-xs text-gray-400">Blockchain-Verified · Legally Binding</p>
              <span className="text-gray-600">·</span>
              <div className="flex items-center gap-1">
                <img src="/solana-logo.png" alt="Solana Blockchain" className="h-3.5 w-3.5" />
                <span className="text-xs font-medium bg-gradient-to-r from-[#9945FF] to-[#14F195] bg-clip-text text-transparent">Solana</span>
              </div>
            </div>
          </div>
        </div>

        {/* Desktop nav */}
        <nav className="hidden md:flex items-center gap-6">
          <a href="#features" className="text-sm text-gray-400 hover:text-white transition-colors">Features</a>
          <a href="#how-it-works" className="text-sm text-gray-400 hover:text-white transition-colors">How It Works</a>
          <a href="#pricing" className="text-sm text-gray-400 hover:text-white transition-colors">Pricing</a>
          <a href="#compliance" className="text-sm text-gray-400 hover:text-white transition-colors">Compliance</a>
        </nav>

        <div className="flex items-center gap-3">
          {/* Mobile hamburger */}
          <button onClick={() => setMobileOpen(!mobileOpen)} className="md:hidden text-gray-400 hover:text-white p-1">
            <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              {mobileOpen ? <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /> : <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />}
            </svg>
          </button>
          {status === 'authenticated' ? (
            <Link href="/dashboard" className="btn-gradient text-white px-6 py-2 rounded-lg font-medium transition-all">
              Dashboard
            </Link>
          ) : (
            <>
              <Link href="/login" className="hidden sm:block text-gray-400 hover:text-white px-4 py-2 rounded-lg font-medium transition-colors">
                Sign In
              </Link>
              <Link href="/signup" className="btn-gradient text-white px-5 py-2 rounded-lg font-medium transition-all text-sm">
                Get Started Free
              </Link>
            </>
          )}
        </div>
      </div>

      {/* Mobile menu */}
      {mobileOpen && (
        <nav className="md:hidden mt-4 pt-4 border-t border-white/5 flex flex-col gap-3">
          <a href="#features" onClick={() => setMobileOpen(false)} className="text-sm text-gray-400 hover:text-white">Features</a>
          <a href="#how-it-works" onClick={() => setMobileOpen(false)} className="text-sm text-gray-400 hover:text-white">How It Works</a>
          <a href="#pricing" onClick={() => setMobileOpen(false)} className="text-sm text-gray-400 hover:text-white">Pricing</a>
          <a href="#compliance" onClick={() => setMobileOpen(false)} className="text-sm text-gray-400 hover:text-white">Compliance</a>
          {status !== 'authenticated' && (
            <Link href="/login" onClick={() => setMobileOpen(false)} className="text-sm text-gray-400 hover:text-white">Sign In</Link>
          )}
        </nav>
      )}
    </header>
  );
}
