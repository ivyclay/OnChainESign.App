"use client";

import { useRef, useState, useEffect, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Eraser, Pen, RotateCcw } from 'lucide-react';

interface SignatureCanvasProps {
  onSignatureChange: (signatureData: string) => void;
  width?: number;
  height?: number;
}

export function SignatureCanvas({ onSignatureChange, width = 500, height = 200 }: SignatureCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [hasDrawn, setHasDrawn] = useState(false);

  const getContext = useCallback(() => {
    const canvas = canvasRef?.current;
    if (!canvas) return null;
    const ctx = canvas?.getContext?.('2d');
    return ctx;
  }, []);

  useEffect(() => {
    const ctx = getContext();
    if (!ctx) return;
    ctx.lineWidth = 2;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.strokeStyle = '#9945FF';
  }, [getContext]);

  const getCoordinates = (e: React.MouseEvent | React.TouchEvent) => {
    const canvas = canvasRef?.current;
    if (!canvas) return { x: 0, y: 0 };
    
    const rect = canvas?.getBoundingClientRect?.() ?? { left: 0, top: 0 };
    
    if ('touches' in e) {
      const touch = e?.touches?.[0];
      return {
        x: (touch?.clientX ?? 0) - (rect?.left ?? 0),
        y: (touch?.clientY ?? 0) - (rect?.top ?? 0),
      };
    }
    return {
      x: (e?.clientX ?? 0) - (rect?.left ?? 0),
      y: (e?.clientY ?? 0) - (rect?.top ?? 0),
    };
  };

  const startDrawing = (e: React.MouseEvent | React.TouchEvent) => {
    e?.preventDefault?.();
    const ctx = getContext();
    if (!ctx) return;
    
    const { x, y } = getCoordinates(e);
    ctx?.beginPath?.();
    ctx?.moveTo?.(x, y);
    setIsDrawing(true);
  };

  const draw = (e: React.MouseEvent | React.TouchEvent) => {
    e?.preventDefault?.();
    if (!isDrawing) return;
    
    const ctx = getContext();
    if (!ctx) return;
    
    const { x, y } = getCoordinates(e);
    ctx?.lineTo?.(x, y);
    ctx?.stroke?.();
    setHasDrawn(true);
  };

  const stopDrawing = () => {
    setIsDrawing(false);
    if (hasDrawn) {
      const canvas = canvasRef?.current;
      const dataUrl = canvas?.toDataURL?.('image/png') ?? '';
      onSignatureChange?.(dataUrl);
    }
  };

  const clearCanvas = () => {
    const canvas = canvasRef?.current;
    const ctx = getContext();
    if (!canvas || !ctx) return;
    ctx?.clearRect?.(0, 0, canvas?.width ?? 0, canvas?.height ?? 0);
    setHasDrawn(false);
    onSignatureChange?.('');
  };

  return (
    <div className="space-y-3">
      <div className="relative border-2 border-dashed border-gray-300 rounded-lg bg-white">
        <canvas
          ref={canvasRef}
          width={width}
          height={height}
          className="w-full touch-none cursor-crosshair"
          style={{ maxWidth: width, height: 'auto', aspectRatio: `${width}/${height}` }}
          onMouseDown={startDrawing}
          onMouseMove={draw}
          onMouseUp={stopDrawing}
          onMouseLeave={stopDrawing}
          onTouchStart={startDrawing}
          onTouchMove={draw}
          onTouchEnd={stopDrawing}
        />
        {!hasDrawn && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none text-gray-400">
            <div className="flex items-center gap-2">
              <Pen className="w-5 h-5" />
              <span>Draw your signature here</span>
            </div>
          </div>
        )}
      </div>
      <div className="flex gap-2">
        <Button type="button" variant="outline" size="sm" onClick={clearCanvas}>
          <RotateCcw className="w-4 h-4 mr-2" />
          Clear
        </Button>
      </div>
    </div>
  );
}
