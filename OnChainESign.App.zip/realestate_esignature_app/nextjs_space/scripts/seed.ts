import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  // Default test account
  const hash1 = await bcrypt.hash('johndoe123', 12);
  await prisma.user.upsert({
    where: { email: 'john@doe.com' },
    update: { passwordHash: hash1, role: 'admin' },
    create: {
      email: 'john@doe.com',
      name: 'John Doe',
      passwordHash: hash1,
      role: 'admin',
      plan: 'pro',
    },
  });

  // Admin user for the app owner
  const hash2 = await bcrypt.hash('OnChain2026!', 12);
  await prisma.user.upsert({
    where: { email: 'admin@onchain-esign.app' },
    update: { passwordHash: hash2, role: 'admin' },
    create: {
      email: 'admin@onchain-esign.app',
      name: 'Admin',
      passwordHash: hash2,
      role: 'admin',
      plan: 'pro',
    },
  });

  // Service account for Open House Realty (Transaction Auditor integration)
  const hash3 = await bcrypt.hash('OHR-Service-2026!', 12);
  await prisma.user.upsert({
    where: { email: 'system@openhouserealtyaz.com' },
    update: { passwordHash: hash3, role: 'service', plan: 'enterprise', name: 'Open House Realty System' },
    create: {
      email: 'system@openhouserealtyaz.com',
      name: 'Open House Realty System',
      passwordHash: hash3,
      role: 'service',
      plan: 'enterprise',
    },
  });

  console.log('Seed complete.');
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(() => prisma.$disconnect());
