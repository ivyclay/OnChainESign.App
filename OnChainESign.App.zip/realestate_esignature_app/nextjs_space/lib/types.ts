export interface DocumentUploadData {
  fileName: string;
  fileType: string;
  fileSize: number;
  cloudPath: string;
  documentHash: string;
  agentName: string;
  agentEmail: string;
}

export interface SignerInfo {
  name: string;
  email: string;
  role: 'broker' | 'agent' | 'client';
}

export interface SignatureData {
  documentId: string;
  signerName: string;
  signerEmail: string;
  signerRole: string;
  signatureType: 'draw' | 'type' | 'upload';
  signatureData: string;
  ipAddress: string;
  userAgent: string;
  deviceInfo: string;
  timezone: string;
  consentGiven: boolean;
  intentConfirmed: boolean;
}

export interface FieldData {
  id?: string;
  fieldType: 'signature' | 'date' | 'initials' | 'text';
  pageNumber: number;
  xPercent: number;
  yPercent: number;
  widthPercent: number;
  heightPercent: number;
  label?: string;
  required?: boolean;
  value?: string;
  assignedPartyId?: string;
}

export interface AuditEntry {
  action: string;
  actor: string;
  actorEmail?: string;
  ipAddress?: string;
  userAgent?: string;
  details?: string;
}

export interface ConsentData {
  consentToElectronicSigning: boolean;
  intentToSign: boolean;
  acknowledgeUETA: boolean;
}

export type DocumentStatus = 'draft' | 'pending' | 'signed' | 'completed';
