import { Connection, Keypair, Transaction, TransactionInstruction, PublicKey, sendAndConfirmTransaction } from '@solana/web3.js';
import bs58 from 'bs58';

const MEMO_PROGRAM_ID = new PublicKey('MemoSq4gqABAXKb96qnH8TysNcWxMyWCqXgDLGmfcHr');

function getConnection(): Connection {
  const network = process.env.SOLANA_NETWORK || 'devnet';
  const url = network === 'mainnet-beta'
    ? 'https://api.mainnet-beta.solana.com'
    : 'https://api.devnet.solana.com';
  return new Connection(url, 'confirmed');
}

function getKeypair(): Keypair {
  const privateKey = process.env.SOLANA_PRIVATE_KEY;
  if (!privateKey) throw new Error('SOLANA_PRIVATE_KEY not set');
  return Keypair.fromSecretKey(bs58.decode(privateKey));
}

export async function mintDocumentHash(documentHash: string, documentId: string): Promise<{ txHash: string; network: string }> {
  const connection = getConnection();
  const payer = getKeypair();
  const network = process.env.SOLANA_NETWORK || 'devnet';

  const memo = JSON.stringify({
    app: 'OnChainESign',
    docId: documentId,
    hash: documentHash,
    ts: new Date().toISOString(),
  });

  const instruction = new TransactionInstruction({
    keys: [{ pubkey: payer.publicKey, isSigner: true, isWritable: true }],
    programId: MEMO_PROGRAM_ID,
    data: Buffer.from(memo, 'utf-8'),
  });

  const transaction = new Transaction().add(instruction);
  const txHash = await sendAndConfirmTransaction(connection, transaction, [payer]);

  return { txHash, network };
}

export function getSolanaExplorerUrl(txHash: string, network?: string): string {
  const net = network || process.env.SOLANA_NETWORK || 'devnet';
  const cluster = net === 'mainnet-beta' ? '' : `?cluster=${net}`;
  return `https://explorer.solana.com/tx/${txHash}${cluster}`;
}

export async function getWalletBalance(): Promise<number> {
  const connection = getConnection();
  const payer = getKeypair();
  const balance = await connection.getBalance(payer.publicKey);
  return balance / 1e9; // Convert lamports to SOL
}
