import crypto from 'crypto';

export function generateDocumentHash(content: string | Buffer): string {
  return crypto.createHash('sha256').update(content).digest('hex');
}

export function generateSignatureHash(signatureData: string, signerEmail: string, timestamp: string): string {
  const combined = `${signatureData}|${signerEmail}|${timestamp}`;
  return crypto.createHash('sha256').update(combined).digest('hex');
}

export function verifyHash(content: string | Buffer, expectedHash: string): boolean {
  const computedHash = generateDocumentHash(content);
  return computedHash === expectedHash;
}
