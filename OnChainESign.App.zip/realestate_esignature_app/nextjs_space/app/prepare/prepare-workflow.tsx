"use client";

import { useState, useCallback } from 'react';
import { Upload, Pen, Calendar, Hash, Type, Trash2, FileText, ArrowRight, ArrowLeft, Loader2, CheckCircle, Copy, Link as LinkIcon, AlertCircle, Users, Plus, X, Mail, Send, ExternalLink } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { PdfViewer } from '@/components/pdf-viewer';
import { FieldOverlay } from '@/components/field-overlay';
import type { FieldData } from '@/lib/types';

type FieldType = 'signature' | 'date' | 'initials' | 'text';

interface Party {
  name: string;
  email: string;
  role: string;
  company: string;
  phone: string;
}

interface SavedParty {
  id: string;
  name: string;
  email: string;
  role: string;
  status: string;
  signingToken?: string;
}

const ROLE_SUGGESTIONS = [
  'Buyer', 'Seller', 'Broker', 'Agent', 'Lender', 'Title Officer',
  'Attorney', 'Witness', 'Notary', 'Tenant', 'Landlord', 'Contractor',
  'Vendor', 'Client', 'Partner', 'Guarantor', 'Executor', 'Trustee',
];

const PARTY_COLORS = [
  { bg: 'bg-blue-100', border: 'border-blue-400', text: 'text-blue-700', dot: 'bg-blue-500' },
  { bg: 'bg-green-100', border: 'border-green-400', text: 'text-green-700', dot: 'bg-green-500' },
  { bg: 'bg-purple-100', border: 'border-purple-400', text: 'text-purple-700', dot: 'bg-purple-500' },
  { bg: 'bg-orange-100', border: 'border-orange-400', text: 'text-orange-700', dot: 'bg-orange-500' },
  { bg: 'bg-pink-100', border: 'border-pink-400', text: 'text-pink-700', dot: 'bg-pink-500' },
  { bg: 'bg-teal-100', border: 'border-teal-400', text: 'text-teal-700', dot: 'bg-teal-500' },
];

const FIELD_TOOLS: { type: FieldType; label: string; icon: React.ReactNode; color: string }[] = [
  { type: 'signature', label: 'Signature', icon: <Pen className="w-4 h-4" />, color: 'bg-blue-500' },
  { type: 'date', label: 'Date', icon: <Calendar className="w-4 h-4" />, color: 'bg-green-500' },
  { type: 'initials', label: 'Initials', icon: <Hash className="w-4 h-4" />, color: 'bg-purple-500' },
  { type: 'text', label: 'Text', icon: <Type className="w-4 h-4" />, color: 'bg-amber-500' },
];

const FIELD_SIZES: Record<FieldType, { w: number; h: number }> = {
  signature: { w: 20, h: 6 },
  date: { w: 15, h: 4 },
  initials: { w: 8, h: 5 },
  text: { w: 25, h: 4 },
};

const emptyParty = (): Party => ({ name: '', email: '', role: '', company: '', phone: '' });

interface UploadedDoc {
  id: string;
  fileName: string;
  url: string;
}

export function PrepareWorkflow() {
  const [step, setStep] = useState<'upload' | 'parties' | 'place' | 'done'>('upload');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [agentName, setAgentName] = useState('');
  const [agentEmail, setAgentEmail] = useState('');
  // Multi-doc support
  const [uploadedDocs, setUploadedDocs] = useState<UploadedDoc[]>([]);
  const [activeDocIndex, setActiveDocIndex] = useState(0);
  const [allFields, setAllFields] = useState<Record<string, FieldData[]>>({});
  // Backward compat aliases
  const docId = uploadedDocs[activeDocIndex]?.id || '';
  const docUrl = uploadedDocs[activeDocIndex]?.url || '';
  const fields = allFields[docId] || [];
  const setFields = (updater: React.SetStateAction<FieldData[]>) => {
    setAllFields(prev => {
      const curr = prev[docId] || [];
      const next = typeof updater === 'function' ? updater(curr) : updater;
      return { ...prev, [docId]: next };
    });
  };
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(0);
  const [activeTool, setActiveTool] = useState<FieldType | null>(null);
  const [copied, setCopied] = useState<string>('');
  const [parties, setParties] = useState<Party[]>([emptyParty(), emptyParty()]);
  const [savedParties, setSavedParties] = useState<SavedParty[]>([]);
  const [selectedPartyId, setSelectedPartyId] = useState<string>('');
  const [inviteLoading, setInviteLoading] = useState(false);
  const [invitesSent, setInvitesSent] = useState(false);
  const [uploadProgress, setUploadProgress] = useState('');
  // All-doc results for done step: docId -> parties with signing tokens
  const [allDocResults, setAllDocResults] = useState<Record<string, SavedParty[]>>({});

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    setSelectedFiles(prev => [...prev, ...files]);
    setError('');
    // Reset input so same file can be re-selected
    e.target.value = '';
  };

  const removeFile = (idx: number) => {
    setSelectedFiles(prev => prev.filter((_, i) => i !== idx));
  };

  const uploadSingleFile = async (file: File, agName: string, agEmail: string): Promise<UploadedDoc> => {
    const presignedRes = await fetch('/api/upload/presigned', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ fileName: file.name, contentType: file.type, isPublic: false }),
    });
    const presigned = await presignedRes.json();
    if (!presigned?.success) throw new Error(presigned?.error || 'Upload URL failed');

    const uploadUrl = presigned.uploadUrl || '';
    const headers: Record<string, string> = { 'Content-Type': file.type };
    if (uploadUrl.includes('content-disposition')) headers['Content-Disposition'] = 'attachment';
    const upRes = await fetch(uploadUrl, { method: 'PUT', headers, body: file });
    if (!upRes.ok) throw new Error(`S3 upload failed for ${file.name}`);

    const docRes = await fetch('/api/documents', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        fileName: file.name,
        fileType: file.type,
        fileSize: file.size,
        cloudPath: presigned.cloud_storage_path,
        agentName: agName,
        agentEmail: agEmail,
        documentContent: file.name,
      }),
    });
    const docData = await docRes.json();
    if (!docData?.success) throw new Error(docData?.error || `Document save failed for ${file.name}`);

    const urlRes = await fetch(`/api/documents/${docData.document.id}/url`);
    const urlData = await urlRes.json();

    return {
      id: docData.document.id,
      fileName: file.name,
      url: urlData?.success && urlData.url ? urlData.url : '',
    };
  };

  const handleUpload = async () => {
    if (selectedFiles.length === 0 || !agentName || !agentEmail) {
      setError('Please fill all fields and select at least one PDF');
      return;
    }
    setLoading(true);
    setError('');
    const uploaded: UploadedDoc[] = [];
    try {
      for (let i = 0; i < selectedFiles.length; i++) {
        setUploadProgress(`Uploading ${i + 1} of ${selectedFiles.length}: ${selectedFiles[i].name}`);
        const doc = await uploadSingleFile(selectedFiles[i], agentName, agentEmail);
        uploaded.push(doc);
      }
      setUploadedDocs(uploaded);
      setActiveDocIndex(0);
      setUploadProgress('');
      setStep('parties');
    } catch (err: any) {
      setError(err?.message || 'Upload failed');
      if (uploaded.length > 0) setUploadedDocs(uploaded);
    } finally {
      setLoading(false);
      setUploadProgress('');
    }
  };

  const addParty = () => setParties(prev => [...prev, emptyParty()]);
  const removeParty = (idx: number) => setParties(prev => prev.filter((_, i) => i !== idx));
  const updateParty = (idx: number, field: keyof Party, value: string) => {
    setParties(prev => prev.map((p, i) => i === idx ? { ...p, [field]: value } : p));
  };

  // Save parties to ALL uploaded documents
  const saveParties = async () => {
    const validParties = parties.filter(p => p.name.trim() && p.email.trim() && p.role.trim());
    if (validParties.length === 0) {
      setError('Please add at least one party with name, email, and role');
      return;
    }
    setLoading(true);
    setError('');
    try {
      // Save parties to each uploaded doc
      for (const doc of uploadedDocs) {
        const res = await fetch('/api/parties', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ documentId: doc.id, parties: validParties }),
        });
        const data = await res.json();
        if (!data?.success) throw new Error(data?.error || `Failed to save parties for ${doc.fileName}`);
      }

      // Fetch saved parties from first doc (they share the same party data)
      const getRes = await fetch(`/api/parties?documentId=${uploadedDocs[0].id}`);
      const getData = await getRes.json();
      if (getData?.success && getData.parties) {
        setSavedParties(getData.parties);
        if (getData.parties.length > 0) {
          setSelectedPartyId(getData.parties[0].id);
        }
      }

      setStep('place');
    } catch (err: any) {
      setError(err?.message || 'Failed to save parties');
    } finally {
      setLoading(false);
    }
  };

  const handlePageClick = useCallback((xPercent: number, yPercent: number) => {
    if (!activeTool) return;
    const size = FIELD_SIZES[activeTool];
    const newField: FieldData = {
      fieldType: activeTool,
      pageNumber: currentPage,
      xPercent: Math.max(0, Math.min(xPercent - size.w / 2, 100 - size.w)),
      yPercent: Math.max(0, Math.min(yPercent - size.h / 2, 100 - size.h)),
      widthPercent: size.w,
      heightPercent: size.h,
      required: true,
      assignedPartyId: selectedPartyId || undefined,
    };
    setFields(prev => [...prev, newField]);
  }, [activeTool, currentPage, selectedPartyId, docId]);

  const removeField = (index: number) => {
    setFields(prev => prev.filter((_, i) => i !== index));
  };

  // Save fields for ALL docs and generate signing links
  const saveFields = async () => {
    // Check that every doc has at least one field
    const docsWithoutFields = uploadedDocs.filter(d => !(allFields[d.id]?.length));
    if (docsWithoutFields.length > 0) {
      setError(`Please place at least one field on: ${docsWithoutFields.map(d => d.fileName).join(', ')}`);
      return;
    }
    setLoading(true);
    setError('');
    try {
      const results: Record<string, SavedParty[]> = {};
      for (let i = 0; i < uploadedDocs.length; i++) {
        const doc = uploadedDocs[i];
        const docFields = allFields[doc.id] || [];
        setUploadProgress(`Saving fields for ${i + 1} of ${uploadedDocs.length}: ${doc.fileName}`);

        const res = await fetch('/api/fields', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ documentId: doc.id, fields: docFields }),
        });
        const data = await res.json();
        if (!data?.success) throw new Error(data?.error || `Save failed for ${doc.fileName}`);

        // Generate signing tokens
        const inviteRes = await fetch('/api/invite', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ documentId: doc.id, sendEmails: false }),
        });
        const inviteData = await inviteRes.json();
        if (inviteData?.success && inviteData.parties) {
          results[doc.id] = inviteData.parties;
        }
      }
      setAllDocResults(results);
      // Use first doc's parties for backward compat
      if (results[uploadedDocs[0]?.id]) {
        setSavedParties(results[uploadedDocs[0].id]);
      }
      setUploadProgress('');
      setStep('done');
    } catch (err: any) {
      setError(err?.message || 'Failed to save fields');
    } finally {
      setLoading(false);
      setUploadProgress('');
    }
  };

  const sendAllInvites = async () => {
    setInviteLoading(true);
    setError('');
    try {
      const results: Record<string, SavedParty[]> = {};
      for (const doc of uploadedDocs) {
        const res = await fetch('/api/invite', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ documentId: doc.id, sendEmails: true }),
        });
        const data = await res.json();
        if (!data?.success) throw new Error(data?.error || `Failed to send invites for ${doc.fileName}`);
        results[doc.id] = data.parties;
      }
      setAllDocResults(results);
      setInvitesSent(true);
    } catch (err: any) {
      setError(err?.message || 'Failed to send invitations');
    } finally {
      setInviteLoading(false);
    }
  };

  const copyLink = (link: string, key: string) => {
    navigator.clipboard.writeText(link);
    setCopied(key);
    setTimeout(() => setCopied(''), 2000);
  };

  const pageFields = fields.filter(f => f.pageNumber === currentPage);

  const getPartyColor = (partyId: string) => {
    const idx = savedParties.findIndex(p => p.id === partyId);
    return PARTY_COLORS[idx % PARTY_COLORS.length] || PARTY_COLORS[0];
  };

  const getPartyName = (partyId: string) => {
    return savedParties.find(p => p.id === partyId)?.name || 'Unassigned';
  };

  const totalFieldsAllDocs = Object.values(allFields).reduce((sum, f) => sum + f.length, 0);

  const resetWorkflow = () => {
    setStep('upload');
    setAllFields({});
    setUploadedDocs([]);
    setActiveDocIndex(0);
    setSelectedFiles([]);
    setParties([emptyParty(), emptyParty()]);
    setSavedParties([]);
    setAllDocResults({});
    setInvitesSent(false);
    setError('');
    setUploadProgress('');
  };

  // When switching active doc, reset page to 1
  const switchDoc = (idx: number) => {
    setActiveDocIndex(idx);
    setCurrentPage(1);
    setTotalPages(0);
  };

  // ========================
  // Step 1: Upload
  // ========================
  if (step === 'upload') {
    return (
      <div className="max-w-2xl mx-auto p-6">
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-white">
              <Upload className="w-5 h-5" />
              Prepare Documents for Signing
            </CardTitle>
            <CardDescription>Upload one or more PDF documents, define transaction parties, then place signature fields.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-5">
            {error && (
              <div className="p-3 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-red-700 text-sm">
                <AlertCircle className="w-4 h-4" /> {error}
              </div>
            )}
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1">Your Name *</label>
                <Input value={agentName} onChange={e => setAgentName(e.target.value)} placeholder="Agent / Broker name" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1">Your Email *</label>
                <Input type="email" value={agentEmail} onChange={e => setAgentEmail(e.target.value)} placeholder="you@email.com" />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">Documents (PDF) *</label>
              <div className="border-2 border-dashed border-white/10 rounded-lg p-6 text-center hover:border-[#9945FF] transition-colors">
                <input type="file" accept=".pdf" multiple onChange={handleFileSelect} className="hidden" id="pdf-up" />
                <label htmlFor="pdf-up" className="cursor-pointer">
                  <Upload className="w-10 h-10 text-gray-400 mx-auto mb-2" />
                  <p className="text-sm"><span className="font-medium text-white">Click to upload</span> one or more PDF files</p>
                  <p className="text-xs text-gray-400 mt-1">You can select multiple files at once</p>
                </label>
              </div>
              {selectedFiles.length > 0 && (
                <div className="mt-3 space-y-2">
                  {selectedFiles.map((file, idx) => (
                    <div key={idx} className="flex items-center justify-between text-sm bg-green-50 border border-green-200 p-2 rounded-lg">
                      <div className="flex items-center gap-2 text-green-700 min-w-0">
                        <FileText className="w-4 h-4 flex-shrink-0" />
                        <span className="truncate">{file.name}</span>
                        <span className="text-xs text-green-500 flex-shrink-0">({(file.size / 1024).toFixed(1)} KB)</span>
                      </div>
                      <button onClick={() => removeFile(idx)} className="text-red-400 hover:text-red-600 p-1 flex-shrink-0">
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                  <p className="text-xs text-gray-500">{selectedFiles.length} file{selectedFiles.length !== 1 ? 's' : ''} selected</p>
                </div>
              )}
            </div>
            {uploadProgress && (
              <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg flex items-center gap-2 text-blue-700 text-sm">
                <Loader2 className="w-4 h-4 animate-spin" /> {uploadProgress}
              </div>
            )}
            <Button onClick={handleUpload} disabled={loading || selectedFiles.length === 0 || !agentName || !agentEmail} className="w-full bg-[#9945FF] hover:bg-[#7c35e0]">
              {loading ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Uploading...</> : <>Upload & Continue <ArrowRight className="w-4 h-4 ml-2" /></>}
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  // ========================
  // Step 2: Parties
  // ========================
  if (step === 'parties') {
    return (
      <div className="max-w-3xl mx-auto p-6">
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-white">
              <Users className="w-5 h-5" />
              Parties to Transaction
            </CardTitle>
            <CardDescription>
              Define all parties involved. Each party will receive unique signing links for {uploadedDocs.length > 1 ? `all ${uploadedDocs.length} documents` : 'this document'}.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {error && (
              <div className="p-3 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-red-700 text-sm">
                <AlertCircle className="w-4 h-4" /> {error}
              </div>
            )}

            {/* Step indicator */}
            <div className="flex items-center gap-2 text-xs text-gray-500 mb-2">
              <span className="bg-green-100 text-green-700 px-2 py-0.5 rounded-full font-medium">✓ Upload</span>
              <ArrowRight className="w-3 h-3" />
              <span className="bg-[#9945FF] text-white px-2 py-0.5 rounded-full font-medium">2. Parties</span>
              <ArrowRight className="w-3 h-3" />
              <span className="bg-white/5 text-gray-500 px-2 py-0.5 rounded-full">3. Fields</span>
              <ArrowRight className="w-3 h-3" />
              <span className="bg-white/5 text-gray-500 px-2 py-0.5 rounded-full">4. Done</span>
            </div>

            {/* Uploaded docs summary */}
            {uploadedDocs.length > 1 && (
              <div className="p-3 bg-[#0f1225] border border-white/10 rounded-lg">
                <p className="text-xs font-medium text-gray-400 mb-1">Documents in this transaction:</p>
                <div className="flex flex-wrap gap-2">
                  {uploadedDocs.map((doc, idx) => (
                    <span key={doc.id} className="inline-flex items-center gap-1 bg-[#12152B] border border-white/10 rounded px-2 py-1 text-xs text-gray-300">
                      <FileText className="w-3 h-3" /> {doc.fileName}
                    </span>
                  ))}
                </div>
              </div>
            )}

            <div className="space-y-4">
              {parties.map((party, idx) => {
                const color = PARTY_COLORS[idx % PARTY_COLORS.length];
                return (
                  <div key={idx} className={`border-2 ${color.border} rounded-lg p-4 ${color.bg} relative`}>
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-2">
                        <div className={`w-3 h-3 rounded-full ${color.dot}`} />
                        <span className={`text-sm font-semibold ${color.text}`}>Party {idx + 1}</span>
                      </div>
                      {parties.length > 1 && (
                        <button onClick={() => removeParty(idx)} className="text-red-400 hover:text-red-600 p-1">
                          <X className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                    <div className="grid md:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-xs font-medium text-gray-400 mb-1">Full Name *</label>
                        <Input value={party.name} onChange={e => updateParty(idx, 'name', e.target.value)} placeholder="John Doe" className="text-sm bg-[#0f1225]" />
                      </div>
                      <div>
                        <label className="block text-xs font-medium text-gray-400 mb-1">Email *</label>
                        <Input type="email" value={party.email} onChange={e => updateParty(idx, 'email', e.target.value)} placeholder="john@example.com" className="text-sm bg-[#0f1225]" />
                      </div>
                      <div>
                        <label className="block text-xs font-medium text-gray-400 mb-1">Role *</label>
                        <input
                          list={`role-suggestions-${idx}`}
                          value={party.role}
                          onChange={e => updateParty(idx, 'role', e.target.value)}
                          placeholder="e.g. Buyer, Attorney, Tenant..."
                          className="w-full border border-white/10 rounded-md px-3 py-2 text-sm bg-[#0f1225] focus:outline-none focus:ring-2 focus:ring-[#9945FF]"
                        />
                        <datalist id={`role-suggestions-${idx}`}>
                          {ROLE_SUGGESTIONS.map(r => <option key={r} value={r} />)}
                        </datalist>
                      </div>
                      <div>
                        <label className="block text-xs font-medium text-gray-400 mb-1">Company</label>
                        <Input value={party.company} onChange={e => updateParty(idx, 'company', e.target.value)} placeholder="Company name (optional)" className="text-sm bg-[#0f1225]" />
                      </div>
                      <div className="md:col-span-2">
                        <label className="block text-xs font-medium text-gray-400 mb-1">Phone</label>
                        <Input value={party.phone} onChange={e => updateParty(idx, 'phone', e.target.value)} placeholder="(555) 123-4567 (optional)" className="text-sm bg-[#0f1225]" />
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            <button
              onClick={addParty}
              className="w-full border-2 border-dashed border-white/10 rounded-lg p-3 text-sm text-gray-500 hover:border-[#9945FF] hover:text-white transition-colors flex items-center justify-center gap-2"
            >
              <Plus className="w-4 h-4" /> Add Another Party
            </button>

            <div className="flex gap-3 pt-2">
              <Button variant="outline" onClick={() => setStep('upload')}>
                <ArrowLeft className="w-4 h-4 mr-1" /> Back
              </Button>
              <Button
                onClick={saveParties}
                disabled={loading || parties.every(p => !p.name.trim() || !p.email.trim() || !p.role.trim())}
                className="flex-1 bg-[#9945FF] hover:bg-[#7c35e0]"
              >
                {loading ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Saving...</> : <>Continue to Field Placement <ArrowRight className="w-4 h-4 ml-2" /></>}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  // ========================
  // Step 4: Done
  // ========================
  if (step === 'done') {
    const baseUrl = typeof window !== 'undefined' ? window.location.origin : '';
    return (
      <div className="max-w-3xl mx-auto p-6">
        <Card className="shadow-lg">
          <CardContent className="pt-8">
            <div className="text-center mb-6">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="w-8 h-8 text-green-600" />
              </div>
              <h2 className="text-2xl font-bold text-white mb-2">
                {uploadedDocs.length > 1 ? `${uploadedDocs.length} Documents` : 'Document'} Ready for Signing!
              </h2>
              <p className="text-gray-400">
                {totalFieldsAllDocs} field(s) placed across {uploadedDocs.length} document{uploadedDocs.length !== 1 ? 's' : ''}
              </p>
            </div>

            {error && (
              <div className="p-3 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-red-700 text-sm mb-4">
                <AlertCircle className="w-4 h-4" /> {error}
              </div>
            )}

            {invitesSent && (
              <div className="p-3 bg-green-50 border border-green-200 rounded-lg flex items-center gap-2 text-green-700 text-sm mb-4">
                <Mail className="w-4 h-4" /> Email invitations sent to all parties successfully!
              </div>
            )}

            {/* Per-document signing links */}
            <div className="space-y-5 mb-6">
              {uploadedDocs.map((doc) => {
                const docParties = allDocResults[doc.id] || savedParties;
                return (
                  <div key={doc.id}>
                    {uploadedDocs.length > 1 && (
                      <div className="flex items-center gap-2 mb-2">
                        <FileText className="w-4 h-4 text-white" />
                        <h3 className="text-sm font-semibold text-white">{doc.fileName}</h3>
                        <span className="text-xs text-gray-400">({(allFields[doc.id] || []).length} fields)</span>
                      </div>
                    )}
                    <div className="space-y-3">
                      {docParties.map((party, idx) => {
                        const color = PARTY_COLORS[idx % PARTY_COLORS.length];
                        const signingUrl = party.signingToken ? `${baseUrl}/sign/party/${party.signingToken}` : '';
                        const copyKey = `${doc.id}-${party.id}`;
                        return (
                          <div key={party.id} className={`border-2 ${color.border} rounded-lg p-4 ${color.bg}`}>
                            <div className="flex items-center justify-between mb-2">
                              <div className="flex items-center gap-2">
                                <div className={`w-3 h-3 rounded-full ${color.dot}`} />
                                <span className={`font-semibold text-sm ${color.text}`}>{party.name}</span>
                                <span className="text-xs text-gray-500 capitalize">({party.role})</span>
                              </div>
                              <span className={`text-xs px-2 py-0.5 rounded-full ${
                                party.status === 'sent' ? 'bg-blue-100 text-blue-700' :
                                party.status === 'signed' ? 'bg-green-100 text-green-700' :
                                'bg-white/5 text-gray-400'
                              }`}>
                                {party.status === 'sent' ? 'Invited' : party.status === 'signed' ? 'Signed' : 'Pending'}
                              </span>
                            </div>
                            <div className="flex items-center gap-2 text-xs text-gray-500 mb-2">
                              <Mail className="w-3 h-3" /> {party.email}
                            </div>
                            {signingUrl && (
                              <div className="bg-white/5 rounded-md p-2 flex items-center gap-2">
                                <LinkIcon className="w-4 h-4 text-white flex-shrink-0" />
                                <input type="text" readOnly value={signingUrl} className="flex-1 bg-transparent text-xs font-mono truncate outline-none text-gray-300" />
                                <Button size="sm" variant="outline" className="h-7 px-2" onClick={() => copyLink(signingUrl, copyKey)}>
                                  {copied === copyKey ? <CheckCircle className="w-3 h-3 text-green-500" /> : <Copy className="w-3 h-3" />}
                                </Button>
                                <Button size="sm" variant="outline" className="h-7 px-2" onClick={() => window.open(signingUrl, '_blank')}>
                                  <ExternalLink className="w-3 h-3" />
                                </Button>
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Action buttons */}
            <div className="flex flex-col sm:flex-row gap-3">
              <Button
                onClick={sendAllInvites}
                disabled={inviteLoading || invitesSent}
                className="flex-1 bg-[#9945FF] hover:bg-[#7c35e0] text-white"
              >
                {inviteLoading ? (
                  <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Sending...</>
                ) : invitesSent ? (
                  <><CheckCircle className="w-4 h-4 mr-2" /> Invitations Sent</>
                ) : (
                  <><Send className="w-4 h-4 mr-2" /> Email All Parties</>
                )}
              </Button>
              <Button onClick={resetWorkflow} variant="outline" className="flex-1">
                Prepare Another Document
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  // ========================
  // Step 3: Field Placement
  // ========================
  return (
    <div className="max-w-7xl mx-auto p-4">
      {/* Step indicator */}
      <div className="flex items-center gap-2 text-xs text-gray-500 mb-4">
        <span className="bg-green-100 text-green-700 px-2 py-0.5 rounded-full font-medium">✓ Upload</span>
        <ArrowRight className="w-3 h-3" />
        <span className="bg-green-100 text-green-700 px-2 py-0.5 rounded-full font-medium">✓ Parties</span>
        <ArrowRight className="w-3 h-3" />
        <span className="bg-[#9945FF] text-white px-2 py-0.5 rounded-full font-medium">3. Fields</span>
        <ArrowRight className="w-3 h-3" />
        <span className="bg-white/5 text-gray-500 px-2 py-0.5 rounded-full">4. Done</span>
      </div>

      {/* Document tabs for multi-doc */}
      {uploadedDocs.length > 1 && (
        <div className="flex items-center gap-2 mb-4 overflow-x-auto pb-1">
          {uploadedDocs.map((doc, idx) => {
            const docFieldCount = (allFields[doc.id] || []).length;
            const isActive = idx === activeDocIndex;
            return (
              <button
                key={doc.id}
                onClick={() => switchDoc(idx)}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-all border-2 ${
                  isActive
                    ? 'bg-[#9945FF] text-white border-[#9945FF] shadow-md'
                    : 'bg-[#0f1225] text-gray-300 border-white/10 hover:border-[#9945FF] hover:text-white'
                }`}
              >
                <FileText className="w-4 h-4" />
                <span className="truncate max-w-[150px]">{doc.fileName}</span>
                {docFieldCount > 0 && (
                  <span className={`text-xs px-1.5 py-0.5 rounded-full ${
                    isActive ? 'bg-white/10' : 'bg-white/5'
                  }`}>
                    {docFieldCount}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      )}

      <div className="flex flex-col lg:flex-row gap-4">
        {/* Left sidebar - Tools */}
        <div className="lg:w-72 flex-shrink-0">
          <Card className="shadow-lg sticky top-4">
            <CardHeader className="pb-3">
              <CardTitle className="text-base text-white">Field Tools</CardTitle>
              <CardDescription className="text-xs">Select a tool, assign a party, then click on the document.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {/* Party assignment selector */}
              {savedParties.length > 0 && (
                <div>
                  <label className="block text-xs font-medium text-gray-400 mb-1">Assign to Party</label>
                  <select
                    value={selectedPartyId}
                    onChange={e => setSelectedPartyId(e.target.value)}
                    className="w-full border border-white/10 rounded-md px-3 py-2 text-sm bg-[#0f1225] focus:outline-none focus:ring-2 focus:ring-[#9945FF]"
                  >
                    <option value="">No assignment</option>
                    {savedParties.map((p, idx) => (
                      <option key={p.id} value={p.id}>
                        {p.name} ({p.role})
                      </option>
                    ))}
                  </select>
                  {selectedPartyId && (
                    <div className="mt-1 flex items-center gap-1">
                      <div className={`w-2 h-2 rounded-full ${getPartyColor(selectedPartyId).dot}`} />
                      <span className="text-xs text-gray-500">Fields will be assigned to {getPartyName(selectedPartyId)}</span>
                    </div>
                  )}
                </div>
              )}

              <div className="border-t pt-2">
                {FIELD_TOOLS.map(tool => (
                  <button
                    key={tool.type}
                    onClick={() => setActiveTool(activeTool === tool.type ? null : tool.type)}
                    className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all mb-1 ${
                      activeTool === tool.type
                        ? `${tool.color} text-white shadow-md`
                        : 'bg-white/5 text-gray-300 hover:bg-gray-200'
                    }`}
                  >
                    {tool.icon} {tool.label}
                  </button>
                ))}
              </div>

              {/* Field summary */}
              <div className="border-t pt-3">
                <p className="text-xs text-gray-500 mb-1">This doc: {fields.length} field(s) · Page: {pageFields.length}</p>
                {uploadedDocs.length > 1 && (
                  <p className="text-xs text-gray-400 mb-2">All docs total: {totalFieldsAllDocs} field(s)</p>
                )}
                {savedParties.length > 0 && (
                  <div className="space-y-1">
                    {savedParties.map((p, idx) => {
                      const color = PARTY_COLORS[idx % PARTY_COLORS.length];
                      const count = fields.filter(f => f.assignedPartyId === p.id).length;
                      return (
                        <div key={p.id} className="flex items-center gap-2 text-xs">
                          <div className={`w-2 h-2 rounded-full ${color.dot}`} />
                          <span className="text-gray-400">{p.name}: {count} field(s)</span>
                        </div>
                      );
                    })}
                    {fields.filter(f => !f.assignedPartyId).length > 0 && (
                      <div className="flex items-center gap-2 text-xs">
                        <div className="w-2 h-2 rounded-full bg-gray-400" />
                        <span className="text-gray-400">Unassigned: {fields.filter(f => !f.assignedPartyId).length} field(s)</span>
                      </div>
                    )}
                  </div>
                )}
              </div>

              {error && <p className="text-xs text-red-500 mt-2">{error}</p>}
              {uploadProgress && <p className="text-xs text-blue-600 mt-2">{uploadProgress}</p>}
              <Button onClick={saveFields} disabled={loading || totalFieldsAllDocs === 0} className="w-full mt-2 bg-[#9945FF] hover:bg-[#7c35e0] text-white">
                {loading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <CheckCircle className="w-4 h-4 mr-2" />}
                Save & Generate Links
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* PDF Viewer */}
        <div className="flex-1 overflow-auto">
          {activeTool && (
            <div className="mb-3 p-2 bg-blue-50 border border-blue-200 rounded-lg text-sm text-blue-700 text-center">
              Click on the document to place a <strong>{activeTool}</strong> field
              {selectedPartyId ? <> for <strong>{getPartyName(selectedPartyId)}</strong></> : ' (unassigned)'}.
            </div>
          )}
          <PdfViewer
            url={docUrl}
            currentPage={currentPage}
            onPageChange={setCurrentPage}
            onTotalPagesChange={setTotalPages}
            onPageClick={activeTool ? handlePageClick : undefined}
          >
            {pageFields.map((field, idx) => {
              const globalIdx = fields.findIndex(f => f === field);
              return (
                <FieldOverlay
                  key={idx}
                  field={field}
                  isAdmin
                  onRemove={() => removeField(globalIdx)}
                />
              );
            })}
          </PdfViewer>
        </div>
      </div>
    </div>
  );
}
