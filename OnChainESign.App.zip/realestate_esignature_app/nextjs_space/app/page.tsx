import { FileSignature, Shield, Clock, CheckCircle, Upload, Pen, Download, MousePointerClick, Cpu, Users, DollarSign, Lock, ArrowRight, Zap, Crown, Building2, Check, Globe, Scale, Fingerprint, Eye } from 'lucide-react';
import Link from 'next/link';
import { HomeHeader } from '@/components/home-header';
import { SolanaBadge } from '@/components/solana-badge';

export default function HomePage() {
  return (
    <main className="min-h-screen bg-[#0B0E17] text-white">
      <HomeHeader />

      {/* Hero Section */}
      <section className="relative py-24 md:py-32 px-6 overflow-hidden">
        <div className="absolute inset-0 bg-grid opacity-30" />
        <div className="absolute inset-0 bg-gradient-to-b from-[#9945FF]/5 via-transparent to-[#14F195]/5" />
        <div className="max-w-4xl mx-auto text-center relative z-10">
          <div className="inline-flex items-center gap-2 bg-[#14F195]/10 text-[#14F195] px-4 py-2 rounded-full text-sm font-medium border border-[#14F195]/20 mb-8">
            <Zap className="w-4 h-4" />
            Start free — 3 signatures/month, no credit card required
          </div>
          <h2 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
            Sign Documents<br />
            <span className="gradient-text">On the Blockchain</span>
          </h2>
          <p className="text-xl text-gray-400 mb-10 max-w-2xl mx-auto">
            Upload, sign, and verify documents with Solana blockchain proof. Legally binding, globally compliant, and 100x cheaper than DocuSign.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              href="/signup"
              className="inline-flex items-center justify-center gap-2 btn-gradient text-white px-8 py-4 rounded-lg font-semibold text-lg transition-all shadow-lg shadow-[#9945FF]/20 hover:shadow-[#9945FF]/40"
            >
              Get Started Free
              <ArrowRight className="w-5 h-5" />
            </Link>
            <a
              href="#how-it-works"
              className="inline-flex items-center justify-center gap-2 bg-white/5 border border-white/10 text-white px-8 py-4 rounded-lg font-semibold text-lg transition-all hover:bg-white/10"
            >
              See How It Works
            </a>
          </div>
          <div className="flex items-center justify-center gap-6 mt-10 text-sm text-gray-500">
            <span className="flex items-center gap-1.5"><Shield className="w-4 h-4 text-[#14F195]" /> ESIGN Act Compliant</span>
            <span className="flex items-center gap-1.5"><Globe className="w-4 h-4 text-[#9945FF]" /> eIDAS (EU) Ready</span>
            <span className="flex items-center gap-1.5"><Lock className="w-4 h-4 text-gray-400" /> 256-bit Encrypted</span>
          </div>
        </div>
      </section>

      {/* Social Proof / Stats Bar */}
      <section className="py-10 px-6 bg-[#0d1020] border-y border-white/5">
        <div className="max-w-5xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
          <div>
            <p className="text-3xl font-bold gradient-text">$0.001</p>
            <p className="text-sm text-gray-500 mt-1">Per signature (gas fee)</p>
          </div>
          <div>
            <p className="text-3xl font-bold text-white">400ms</p>
            <p className="text-sm text-gray-500 mt-1">Blockchain confirmation</p>
          </div>
          <div>
            <p className="text-3xl font-bold text-[#14F195]">50+</p>
            <p className="text-sm text-gray-500 mt-1">Countries supported</p>
          </div>
          <div>
            <p className="text-3xl font-bold text-[#9945FF]">100%</p>
            <p className="text-sm text-gray-500 mt-1">Tamper-proof records</p>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section id="how-it-works" className="py-20 px-6 scroll-mt-20">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-14">
            <h3 className="text-3xl md:text-4xl font-bold mb-3">How It <span className="gradient-text">Works</span></h3>
            <p className="text-gray-400 text-lg">Five simple steps — no technical knowledge required</p>
          </div>
          <div className="grid md:grid-cols-5 gap-4">
            {[
              { icon: <Upload className="w-7 h-7 text-[#9945FF]" />, title: '1. Upload', desc: 'Upload any PDF document — contracts, agreements, forms.' },
              { icon: <Users className="w-7 h-7 text-[#14F195]" />, title: '2. Add Parties', desc: 'Define buyers, sellers, agents, attorneys — any role.' },
              { icon: <MousePointerClick className="w-7 h-7 text-blue-400" />, title: '3. Place Fields', desc: 'Click to add signature, date, and text fields on pages.' },
              { icon: <Pen className="w-7 h-7 text-[#9945FF]" />, title: '4. Sign', desc: 'Each party signs via a unique, secure link sent to them.' },
              { icon: <CheckCircle className="w-7 h-7 text-[#14F195]" />, title: '5. Verify', desc: 'Get a blockchain-verified Certificate of Completion.' },
            ].map((item, i) => (
              <div key={i} className="glass-card rounded-xl p-5 text-center hover:border-[#9945FF]/30 transition-colors">
                <div className="w-14 h-14 bg-white/5 rounded-full flex items-center justify-center mx-auto mb-3">
                  {item.icon}
                </div>
                <h4 className="text-sm font-semibold text-white mb-1">{item.title}</h4>
                <p className="text-gray-400 text-xs">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features — Why OnChainESign */}
      <section id="features" className="py-20 px-6 bg-[#0d1020] scroll-mt-20">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-14">
            <h3 className="text-3xl md:text-4xl font-bold mb-3">Why <span className="gradient-text">OnChainESign</span>?</h3>
            <p className="text-gray-400 text-lg">Everything you need to sign documents — nothing you don&apos;t</p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { icon: <Cpu className="w-8 h-8 text-[#9945FF]" />, title: 'Blockchain Verification', desc: 'Every signature hash is minted on Solana. Immutable, tamper-proof, and publicly verifiable forever.' },
              { icon: <DollarSign className="w-8 h-8 text-[#14F195]" />, title: '100x Cheaper', desc: 'No $30+/month subscriptions. Our free tier gives you 3 signatures/month. Pro is just $29/mo for unlimited.' },
              { icon: <Shield className="w-8 h-8 text-[#9945FF]" />, title: 'Legally Binding', desc: 'Full compliance with ESIGN Act, UETA (all 50 US states), eIDAS (EU), and international e-sign laws.' },
              { icon: <Users className="w-8 h-8 text-[#14F195]" />, title: 'Multi-Party Signing', desc: 'Define unlimited parties — buyers, sellers, brokers, attorneys. Each gets a unique signing link.' },
              { icon: <Fingerprint className="w-8 h-8 text-[#9945FF]" />, title: 'Complete Audit Trail', desc: 'Every action logged with timestamps, IP addresses, and device info. Full Certificate of Completion.' },
              { icon: <Eye className="w-8 h-8 text-[#14F195]" />, title: 'Real-Time Tracking', desc: 'See who viewed, who signed, and who hasn\'t — all from your dashboard. Email notifications included.' },
              { icon: <Lock className="w-8 h-8 text-[#9945FF]" />, title: 'SHA-256 Hashing', desc: 'Documents are hashed with SHA-256. Any modification invalidates the signature — guaranteed integrity.' },
              { icon: <Globe className="w-8 h-8 text-[#14F195]" />, title: 'Works Everywhere', desc: 'Sign from any device — desktop, tablet, or phone. No app download required. Just click and sign.' },
              { icon: <Clock className="w-8 h-8 text-[#9945FF]" />, title: 'Done in Minutes', desc: 'Upload, place fields, send links. Most documents are fully signed in under 10 minutes.' },
            ].map((item, i) => (
              <div key={i} className="glass-card rounded-xl p-6 hover:border-[#9945FF]/30 transition-colors">
                <div className="w-12 h-12 bg-white/5 rounded-lg flex items-center justify-center mb-4">
                  {item.icon}
                </div>
                <h4 className="font-semibold text-white mb-2">{item.title}</h4>
                <p className="text-gray-400 text-sm leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Use Cases */}
      <section className="py-20 px-6">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-14">
            <h3 className="text-3xl md:text-4xl font-bold mb-3">Built for <span className="gradient-text">Every Industry</span></h3>
            <p className="text-gray-400 text-lg">From real estate to legal — if it needs a signature, we handle it</p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { emoji: '🏠', title: 'Real Estate', desc: 'Purchase agreements, leases, disclosures, closing docs' },
              { emoji: '⚖️', title: 'Legal', desc: 'Contracts, NDAs, retainers, settlement agreements' },
              { emoji: '🏢', title: 'Business', desc: 'Vendor agreements, SOWs, employment offers, invoices' },
              { emoji: '🏦', title: 'Finance', desc: 'Loan documents, account openings, compliance forms' },
            ].map((item, i) => (
              <div key={i} className="glass-card rounded-xl p-5 text-center hover:border-[#14F195]/30 transition-colors">
                <span className="text-3xl mb-3 block">{item.emoji}</span>
                <h4 className="font-semibold text-white mb-1 text-sm">{item.title}</h4>
                <p className="text-gray-500 text-xs">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Preview */}
      <section id="pricing" className="py-20 px-6 bg-[#0d1020] scroll-mt-20">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-14">
            <h3 className="text-3xl md:text-4xl font-bold mb-3">Simple, <span className="gradient-text">Transparent</span> Pricing</h3>
            <p className="text-gray-400 text-lg">Start free. Upgrade when you&apos;re ready. No hidden fees.</p>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {/* Free */}
            <div className="glass-card rounded-xl p-6 hover:border-[#14F195]/30 transition-colors">
              <div className="text-center mb-6">
                <div className="w-12 h-12 bg-white/5 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Zap className="w-6 h-6 text-[#14F195]" />
                </div>
                <h4 className="text-lg font-bold text-white">Free</h4>
                <p className="text-4xl font-bold gradient-text mt-2">$0</p>
                <p className="text-gray-500 text-sm">forever</p>
              </div>
              <ul className="space-y-2.5 mb-6">
                {['3 signatures per month', 'Up to 3 parties per doc', 'Blockchain verification', 'Email notifications', 'Audit trail & certificates'].map((f, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm"><Check className="w-4 h-4 text-[#14F195] flex-shrink-0 mt-0.5" /><span className="text-gray-300">{f}</span></li>
                ))}
              </ul>
              <Link href="/signup" className="block w-full text-center bg-white/5 border border-white/10 text-white px-4 py-2.5 rounded-lg font-medium hover:bg-white/10 transition-colors">
                Start Free
              </Link>
            </div>

            {/* Pro */}
            <div className="glass-card rounded-xl p-6 border-2 !border-[#9945FF]/50 relative shadow-xl shadow-[#9945FF]/10 scale-[1.02]">
              <div className="absolute top-0 right-0 bg-gradient-to-r from-[#9945FF] to-[#14F195] text-white text-xs px-3 py-1 rounded-bl-lg font-semibold">POPULAR</div>
              <div className="text-center mb-6">
                <div className="w-12 h-12 bg-[#9945FF]/10 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Crown className="w-6 h-6 text-[#9945FF]" />
                </div>
                <h4 className="text-lg font-bold text-white">Pro</h4>
                <p className="text-4xl font-bold gradient-text mt-2">$29</p>
                <p className="text-gray-500 text-sm">/month</p>
              </div>
              <ul className="space-y-2.5 mb-6">
                {['Unlimited signatures', 'Unlimited parties per doc', 'Priority blockchain minting', 'Bulk email invitations', 'Advanced audit logs', 'API access'].map((f, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm"><Check className="w-4 h-4 text-[#14F195] flex-shrink-0 mt-0.5" /><span className="text-gray-300">{f}</span></li>
                ))}
              </ul>
              <Link href="/signup" className="block w-full text-center btn-gradient text-white px-4 py-2.5 rounded-lg font-medium transition-all">
                Start Free, Upgrade Anytime
              </Link>
            </div>

            {/* Enterprise */}
            <div className="glass-card rounded-xl p-6 hover:border-[#14F195]/30 transition-colors">
              <div className="text-center mb-6">
                <div className="w-12 h-12 bg-white/5 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Building2 className="w-6 h-6 text-[#14F195]" />
                </div>
                <h4 className="text-lg font-bold text-white">Enterprise</h4>
                <p className="text-4xl font-bold gradient-text mt-2">$99</p>
                <p className="text-gray-500 text-sm">/month</p>
              </div>
              <ul className="space-y-2.5 mb-6">
                {['Everything in Pro', 'Team management', 'White-label embedding', 'Dedicated support', 'Custom integrations', 'SLA guarantees'].map((f, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm"><Check className="w-4 h-4 text-[#14F195] flex-shrink-0 mt-0.5" /><span className="text-gray-300">{f}</span></li>
                ))}
              </ul>
              <Link href="/pricing" className="block w-full text-center bg-white/5 border border-white/10 text-white px-4 py-2.5 rounded-lg font-medium hover:bg-white/10 transition-colors">
                Contact Sales
              </Link>
            </div>
          </div>
          <p className="text-center text-gray-500 text-sm mt-8">All plans include Solana blockchain verification. Blockchain gas fees (~$0.001/doc) are separate and negligible.</p>
        </div>
      </section>

      {/* Compliance */}
      <section id="compliance" className="py-20 px-6 scroll-mt-20">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-14">
            <h3 className="text-3xl md:text-4xl font-bold mb-3">Globally <span className="gradient-text">Compliant</span></h3>
            <p className="text-gray-400 text-lg">Recognized under electronic signature laws in 50+ countries</p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { flag: '🇺🇸', region: 'United States', law: 'ESIGN Act & UETA', desc: 'All 50 states' },
              { flag: '🇪🇺', region: 'European Union', law: 'eIDAS Regulation', desc: '27 EU member states' },
              { flag: '🇬🇧', region: 'United Kingdom', law: 'ECA 2000 & UK eIDAS', desc: 'Post-Brexit compliant' },
              { flag: '🇨🇦', region: 'Canada', law: 'PIPEDA & UECA', desc: 'All provinces' },
            ].map((item, i) => (
              <div key={i} className="glass-card rounded-xl p-5 text-center hover:border-[#9945FF]/30 transition-colors">
                <span className="text-3xl mb-2 block">{item.flag}</span>
                <h4 className="font-semibold text-white text-sm mb-1">{item.region}</h4>
                <p className="text-[#14F195] text-xs font-medium">{item.law}</p>
                <p className="text-gray-500 text-xs mt-1">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Comparison */}
      <section className="py-20 px-6 bg-[#0d1020]">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-14">
            <h3 className="text-3xl md:text-4xl font-bold mb-3">How We <span className="gradient-text">Compare</span></h3>
            <p className="text-gray-400 text-lg">See why teams are switching to OnChainESign</p>
          </div>
          <div className="glass-card rounded-xl overflow-hidden">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-white/10">
                  <th className="text-left p-4 text-gray-400 font-medium">Feature</th>
                  <th className="p-4 text-gray-400 font-medium">DocuSign</th>
                  <th className="p-4 text-[#14F195] font-bold">OnChainESign</th>
                </tr>
              </thead>
              <tbody className="text-gray-300">
                {[
                  ['Starting price', '$25/mo', 'Free (3/mo)'],
                  ['Blockchain proof', '❌', '✅ Solana'],
                  ['Tamper detection', 'Basic', 'SHA-256 + On-chain'],
                  ['Multi-party signing', '✅', '✅'],
                  ['Audit certificate', '✅', '✅ + Blockchain'],
                  ['Open verification', '❌', '✅ Public ledger'],
                  ['Cost per signature', '~$1.50', '~$0.001'],
                ].map((row, i) => (
                  <tr key={i} className="border-b border-white/5">
                    <td className="p-4 text-gray-400">{row[0]}</td>
                    <td className="p-4 text-center">{row[1]}</td>
                    <td className="p-4 text-center font-medium">{row[2]}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-24 px-6 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-[#9945FF]/10 to-[#14F195]/10" />
        <div className="absolute inset-0 bg-[#0B0E17]/80" />
        <div className="max-w-3xl mx-auto text-center relative z-10">
          <h3 className="text-3xl md:text-4xl font-bold mb-4">Ready to Sign <span className="gradient-text">On-Chain</span>?</h3>
          <p className="text-gray-400 mb-4 text-lg">Join the future of document signing. Start with 3 free signatures/month.</p>
          <p className="text-gray-500 mb-8 text-sm">No credit card required · Set up in under 60 seconds</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              href="/signup"
              className="inline-flex items-center justify-center gap-2 btn-gradient text-white px-8 py-4 rounded-lg font-semibold text-lg transition-all shadow-lg shadow-[#9945FF]/20"
            >
              Create Free Account
              <ArrowRight className="w-5 h-5" />
            </Link>
            <Link
              href="/pricing"
              className="inline-flex items-center justify-center gap-2 bg-white/5 border border-white/10 text-white px-8 py-4 rounded-lg font-semibold text-lg transition-all hover:bg-white/10"
            >
              View Full Pricing
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-10 px-6 bg-[#080a14] border-t border-white/5">
        <div className="max-w-5xl mx-auto">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-3">
              <FileSignature className="w-6 h-6 text-[#9945FF]" />
              <span className="font-bold text-white">OnChainESign</span>
            </div>
            <div className="flex items-center gap-6 text-sm text-gray-500">
              <Link href="/pricing" className="hover:text-gray-300 transition-colors">Pricing</Link>
              <Link href="/login" className="hover:text-gray-300 transition-colors">Sign In</Link>
              <Link href="/signup" className="hover:text-gray-300 transition-colors">Get Started</Link>
            </div>
            <SolanaBadge />
          </div>
          <div className="text-center mt-8 pt-6 border-t border-white/5">
            <p className="text-gray-500 text-sm">&copy; 2026 OnChainESign. All rights reserved.</p>
            <p className="text-xs text-gray-600 mt-1">Compliant with ESIGN Act, UETA, eIDAS (EU), UK ECA 2000, and international e-signature regulations.</p>
          </div>
        </div>
      </footer>
    </main>
  );
}
