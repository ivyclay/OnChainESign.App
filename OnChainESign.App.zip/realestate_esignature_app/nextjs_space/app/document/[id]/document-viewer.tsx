"use client";

import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { FileText, Download, Clock, User, Shield, Loader2, AlertCircle, CheckCircle, ExternalLink, Cpu } from 'lucide-react';
import { PdfViewer } from '@/components/pdf-viewer';
import { FieldOverlay } from '@/components/field-overlay';
import type { FieldData } from '@/lib/types';

interface Signature {
  id: string;
  signerName: string;
  signerEmail: string;
  signerRole: string;
  signatureType: string;
  signedAt: string;
  signatureHash: string;
}

interface AuditLog {
  id: string;
  action: string;
  actor: string;
  actorEmail?: string;
  timestamp: string;
  details?: string;
}

interface DocumentData {
  id: string;
  fileName: string;
  fileType: string;
  status: string;
  agentName: string;
  agentEmail: string;
  documentHash: string;
  blockchainTxHash?: string;
  blockchainNetwork?: string;
  createdAt: string;
  signatures: Signature[];
  auditLogs: AuditLog[];
}

export function DocumentViewer({ documentId }: { documentId: string }) {
  const [document, setDocument] = useState<DocumentData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [documentUrl, setDocumentUrl] = useState('');
  const [fields, setFields] = useState<FieldData[]>([]);
  const [parties, setParties] = useState<any[]>([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(0);

  useEffect(() => {
    const fetchDocument = async () => {
      try {
        const [docRes, urlRes, fieldRes, partyRes] = await Promise.all([
          fetch(`/api/documents?id=${documentId ?? ''}`),
          fetch(`/api/documents/${documentId}/url`),
          fetch(`/api/fields?documentId=${documentId}`),
          fetch(`/api/parties?documentId=${documentId}`),
        ]);

        const data = await docRes?.json?.() ?? {};
        if (!data?.success) throw new Error(data?.error ?? 'Failed to fetch document');
        setDocument(data?.document ?? null);

        const urlData = await urlRes?.json?.() ?? {};
        if (urlData?.success) setDocumentUrl(urlData?.url ?? '');

        const fieldData = await fieldRes?.json?.() ?? {};
        const partyData = await partyRes?.json?.() ?? {};
        if (partyData?.success && partyData?.parties) {
          setParties(partyData.parties);
        }

        if (fieldData?.success && fieldData?.fields) {
          setFields(fieldData.fields.map((f: any) => ({
            id: f.id,
            fieldType: f.fieldType,
            pageNumber: f.pageNumber,
            xPercent: f.xPercent,
            yPercent: f.yPercent,
            widthPercent: f.widthPercent,
            heightPercent: f.heightPercent,
            label: f.label,
            required: f.required,
            value: f.value || undefined,
          })));
        }
      } catch (err: unknown) {
        const errorMessage = err instanceof Error ? err?.message : 'Failed to load document';
        setError(errorMessage ?? 'Failed to load document');
      } finally {
        setLoading(false);
      }
    };

    if (documentId) fetchDocument?.();
  }, [documentId]);

  const downloadCertificate = (signatureId: string) => {
    const link = window?.document?.createElement?.('a');
    if (link) {
      link.href = `/api/certificate?signatureId=${signatureId ?? ''}&format=pdf`;
      link.download = `certificate-${signatureId ?? ''}.pdf`;
      link?.click?.();
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Loader2 className="w-8 h-8 animate-spin text-[#9945FF]" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="max-w-2xl mx-auto p-6">
        <Card className="border-red-200">
          <CardContent className="pt-6">
            <div className="flex items-center gap-3 text-red-600">
              <AlertCircle className="w-6 h-6" />
              <span>{error}</span>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!document) {
    return (
      <div className="max-w-2xl mx-auto p-6">
        <Card>
          <CardContent className="pt-6 text-center text-gray-500">
            Document not found
          </CardContent>
        </Card>
      </div>
    );
  }

  const statusColors: Record<string, string> = {
    draft: 'bg-[#1a1d35] text-white',
    pending: 'bg-yellow-500/10 text-yellow-800',
    signed: 'bg-[#14F195]/10 text-[#14F195]',
    completed: 'bg-blue-500/10 text-blue-800',
  };

  const pageFields = fields.filter(f => f.pageNumber === currentPage);

  return (
    <div className="max-w-5xl mx-auto p-4 md:p-6 space-y-6">
      {/* Document Info */}
      <Card className="shadow-lg">
        <CardHeader>
          <div className="flex items-start justify-between">
            <div>
              <CardTitle className="flex items-center gap-2 text-[#9945FF]">
                <FileText className="w-5 h-5" />
                {document?.fileName ?? 'Document'}
              </CardTitle>
              <p className="text-sm text-gray-500 mt-1">
                Uploaded on {document?.createdAt ? new Date(document?.createdAt)?.toLocaleDateString?.() : 'N/A'}
              </p>
            </div>
            <span className={`px-3 py-1 rounded-full text-sm font-medium capitalize ${statusColors?.[document?.status ?? ''] ?? 'bg-[#1a1d35] text-gray-400'}`}>
              {document?.status ?? 'Unknown'}
            </span>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <p className="text-sm text-gray-500">Initiating Agent</p>
              <p className="font-medium">{document?.agentName ?? 'N/A'}</p>
              <p className="text-sm text-gray-400">{document?.agentEmail ?? 'N/A'}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500">Document Hash</p>
              <p className="font-mono text-xs break-all bg-[#1a1d35] text-[#14F195] p-2 rounded mt-1">
                {document?.documentHash ?? 'N/A'}
              </p>
            </div>
          </div>

          {/* Blockchain status */}
          {document?.blockchainTxHash && (
            <div className="mt-4 bg-purple-50 border border-purple-200 rounded-lg p-3 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Cpu className="w-5 h-5 text-purple-600" />
                <div>
                  <p className="text-sm font-medium text-purple-800">Blockchain Verified</p>
                  <p className="text-xs text-purple-600 font-mono">{document.blockchainTxHash.slice(0, 24)}...</p>
                </div>
              </div>
              <a
                href={`https://explorer.solana.com/tx/${document.blockchainTxHash}?cluster=${document.blockchainNetwork || 'devnet'}`}
                target="_blank"
                rel="noopener noreferrer"
                className="text-xs text-purple-600 hover:text-purple-800 flex items-center gap-1"
              >
                <ExternalLink className="w-3 h-3" /> Explorer
              </a>
            </div>
          )}

          {documentUrl && (
            <div className="mt-4">
              <Button
                onClick={() => {
                  const link = window?.document?.createElement?.('a');
                  if (link) {
                    link.href = documentUrl;
                    link.download = document?.fileName ?? 'document';
                    link?.click?.();
                  }
                }}
                className="bg-[#9945FF] hover:bg-[#7c35e0]"
              >
                <Download className="w-4 h-4 mr-2" />
                Download Document
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Transaction Parties */}
      {parties.length > 0 && (
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-[#9945FF]">
              <User className="w-5 h-5" />
              Parties to Transaction
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-3">
              {parties.map((party: any) => (
                <div key={party.id} className="border rounded-lg p-3 bg-[#0f1225]">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-medium text-sm">{party.name}</span>
                    <span className="text-xs px-2 py-0.5 bg-[#9945FF]/10 text-[#9945FF] rounded capitalize">
                      {party.role?.replace('_', ' ')}
                    </span>
                  </div>
                  <p className="text-xs text-gray-400">{party.email}</p>
                  {party.company && <p className="text-xs text-gray-500">{party.company}</p>}
                  {party.phone && <p className="text-xs text-gray-500">{party.phone}</p>}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* PDF with fields overlay */}
      {documentUrl && fields.length > 0 && (
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="text-base text-[#9945FF]">Signed Document Preview</CardTitle>
          </CardHeader>
          <CardContent>
            <PdfViewer
              url={documentUrl}
              currentPage={currentPage}
              onPageChange={setCurrentPage}
              onTotalPagesChange={setTotalPages}
            >
              {pageFields.map((field, idx) => (
                <FieldOverlay key={idx} field={field} />
              ))}
            </PdfViewer>
          </CardContent>
        </Card>
      )}

      {/* Signatures */}
      {(document?.signatures?.length ?? 0) > 0 && (
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-[#9945FF]">
              <CheckCircle className="w-5 h-5" />
              Signatures
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {document?.signatures?.map?.((sig) => (
                <div key={sig?.id ?? ''} className="border rounded-lg p-4 bg-[#14F195]/10">
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <User className="w-4 h-4 text-[#14F195]" />
                        <span className="font-medium">{sig?.signerName ?? 'Unknown'}</span>
                        <span className="text-sm px-2 py-0.5 bg-[#14F195]/20 text-[#14F195] rounded capitalize">
                          {sig?.signerRole ?? 'Unknown'}
                        </span>
                      </div>
                      <p className="text-sm text-gray-400 mt-1">{sig?.signerEmail ?? 'N/A'}</p>
                      <p className="text-sm text-gray-500 mt-2 flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        Signed: {sig?.signedAt ? new Date(sig?.signedAt)?.toLocaleString?.() : 'N/A'}
                      </p>
                    </div>
                    <Button
                      size="sm"
                      onClick={() => downloadCertificate(sig?.id ?? '')}
                      className="bg-[#9945FF] hover:bg-[#7c35e0] text-white"
                    >
                      <Download className="w-4 h-4 mr-1" />
                      Certificate
                    </Button>
                  </div>
                  <div className="mt-3 pt-3 border-t">
                    <p className="text-xs text-gray-500">Signature Hash:</p>
                    <p className="font-mono text-xs break-all bg-[#12152B] p-2 rounded mt-1">
                      {sig?.signatureHash ?? 'N/A'}
                    </p>
                  </div>
                </div>
              )) ?? null}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Audit Log */}
      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-[#9945FF]">
            <Shield className="w-5 h-5" />
            Audit Trail
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {document?.auditLogs?.map?.((log) => (
              <div key={log?.id ?? ''} className="flex items-start gap-3 p-3 bg-[#0f1225] rounded-lg">
                <div className="w-2 h-2 rounded-full bg-[#9945FF] mt-2" />
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <span className="font-medium text-sm">{log?.action?.replace?.(/_/g, ' ') ?? 'Unknown'}</span>
                    <span className="text-xs text-gray-500">
                      {log?.timestamp ? new Date(log?.timestamp)?.toLocaleString?.() : 'N/A'}
                    </span>
                  </div>
                  <p className="text-sm text-gray-400">
                    by {log?.actor ?? 'Unknown'} {log?.actorEmail ? `(${log?.actorEmail})` : ''}
                  </p>
                </div>
              </div>
            )) ?? null}
          </div>
        </CardContent>
      </Card>

      {/* Compliance Notice */}
      <div className="p-4 bg-[#14F195]/10 border border-[#14F195]/20 rounded-lg">
        <p className="text-sm text-[#14F195] flex items-center gap-2">
          <Shield className="w-4 h-4" />
          This document and all signatures are blockchain-verified and compliant with the U.S. ESIGN Act, UETA, EU eIDAS Regulation, and applicable international e-signature laws.
        </p>
      </div>
    </div>
  );
}
