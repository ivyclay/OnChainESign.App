"use client";

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Download, Printer, Loader2, AlertCircle } from 'lucide-react';

export function CertificateViewer({ signatureId }: { signatureId: string }) {
  const [htmlContent, setHtmlContent] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchCertificate = async () => {
      try {
        const response = await fetch(`/api/certificate?signatureId=${signatureId ?? ''}&format=html`);
        
        if (!response?.ok) {
          throw new Error('Failed to fetch certificate');
        }
        
        const html = await response?.text?.() ?? '';
        setHtmlContent(html);
      } catch (err: unknown) {
        const errorMessage = err instanceof Error ? err?.message : 'Failed to load certificate';
        setError(errorMessage ?? 'Failed to load certificate');
      } finally {
        setLoading(false);
      }
    };

    if (signatureId) {
      fetchCertificate?.();
    }
  }, [signatureId]);

  const downloadPDF = () => {
    const link = document?.createElement?.('a');
    if (link) {
      link.href = `/api/certificate?signatureId=${signatureId ?? ''}&format=pdf`;
      link.download = `certificate-${signatureId ?? ''}.pdf`;
      link?.click?.();
    }
  };

  const printCertificate = () => {
    window?.print?.();
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Loader2 className="w-8 h-8 animate-spin text-[#9945FF]" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="max-w-2xl mx-auto p-6">
        <div className="bg-red-50 border border-red-200 rounded-lg p-6 flex items-center gap-3 text-red-600">
          <AlertCircle className="w-6 h-6" />
          <span>{error}</span>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto p-4 md:p-6">
      {/* Action Buttons */}
      <div className="flex gap-3 mb-6 print:hidden">
        <Button onClick={downloadPDF} className="bg-[#9945FF] hover:bg-[#7c35e0]">
          <Download className="w-4 h-4 mr-2" />
          Download PDF
        </Button>
        <Button onClick={printCertificate} variant="outline">
          <Printer className="w-4 h-4 mr-2" />
          Print
        </Button>
      </div>

      {/* Certificate Content */}
      <div 
        className="bg-[#12152B] rounded-lg shadow-lg overflow-hidden"
        dangerouslySetInnerHTML={{ __html: htmlContent ?? '' }}
      />
    </div>
  );
}
