import { CertificateViewer } from './certificate-viewer';
import { FileSignature } from 'lucide-react';
import Link from 'next/link';

export default function CertificatePage({ params }: { params: { signatureId: string } }) {
  return (
    <main className="min-h-screen bg-[#0B0E17]">
      <header className="bg-[#0B0E17]/95 backdrop-blur-xl border-b border-white/5 text-white py-3 px-4 sticky top-0 z-50 print:hidden">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <FileSignature className="w-6 h-6 text-[#9945FF]" />
            <span className="font-semibold text-white">OnChainESign</span>
          </Link>
        </div>
      </header>
      <CertificateViewer signatureId={params?.signatureId ?? ''} />
    </main>
  );
}
