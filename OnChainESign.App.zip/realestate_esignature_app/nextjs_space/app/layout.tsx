import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import './globals.css';
import { Providers } from '@/components/providers';

const inter = Inter({ subsets: ['latin'] });

export const dynamic = 'force-dynamic';

export async function generateMetadata(): Promise<Metadata> {
  const baseUrl = process.env.NEXTAUTH_URL ?? 'http://localhost:3000';
  
  return {
    metadataBase: new URL(baseUrl),
    title: 'OnChainESign | Blockchain-Verified Electronic Signatures',
    description: 'Decentralized, blockchain-verified electronic signatures. Secure, legally binding e-signatures with Solana on-chain verification. UETA & ESIGN Act compliant.',
    icons: {
      icon: '/favicon.svg',
      shortcut: '/favicon.svg',
    },
    openGraph: {
      title: 'OnChainESign | Blockchain-Verified Electronic Signatures',
      description: 'Decentralized electronic signatures with Solana blockchain verification. Secure, affordable, legally binding.',
      images: ['/og-image.png'],
      type: 'website',
    },
  };
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <head>
        <script src="https://apps.abacus.ai/chatllm/appllm-lib.js"></script>
      </head>
      <body className={inter?.className ?? ''}>
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
