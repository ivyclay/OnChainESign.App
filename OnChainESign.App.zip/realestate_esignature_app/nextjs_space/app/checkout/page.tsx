"use client";

import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter, useSearchParams } from 'next/navigation';
import { PayPalScriptProvider, PayPalButtons } from '@paypal/react-paypal-js';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { CheckCircle, Shield, ArrowLeft, Loader2, AlertCircle, FileSignature, Zap, Crown } from 'lucide-react';
import Link from 'next/link';

const PLAN_DETAILS: Record<string, { name: string; price: string; period: string; features: string[]; icon: React.ReactNode }> = {
  pro_monthly: {
    name: 'Pro Monthly',
    price: '$29',
    period: '/month',
    features: ['Unlimited documents', 'Priority support', 'Custom branding', 'Blockchain verification', 'Team collaboration'],
    icon: <Zap className="w-6 h-6 text-[#9945FF]" />,
  },
  pro_annual: {
    name: 'Pro Annual',
    price: '$290',
    period: '/year (save $58)',
    features: ['Unlimited documents', 'Priority support', 'Custom branding', 'Blockchain verification', 'Team collaboration', '2 months free'],
    icon: <Crown className="w-6 h-6 text-[#9945FF]" />,
  },
  per_document: {
    name: 'Single Document',
    price: '$4.99',
    period: 'one-time',
    features: ['1 additional document', 'Full blockchain verification', 'Certificate of completion', 'ESIGN Act compliant'],
    icon: <FileSignature className="w-6 h-6 text-[#9945FF]" />,
  },
};

function CheckoutContent() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const searchParams = useSearchParams();
  const planType = searchParams.get('plan') || 'pro_monthly';
  const plan = PLAN_DETAILS[planType];

  const [clientId, setClientId] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [paymentSuccess, setPaymentSuccess] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/login?callbackUrl=/checkout?plan=' + planType);
      return;
    }
    fetch('/api/paypal/client-id')
      .then(r => r.json())
      .then(data => {
        setClientId(data.clientId || '');
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, [status, router, planType]);

  if (status === 'loading' || loading) {
    return (
      <div className="min-h-screen bg-[#0B0E17] flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-[#9945FF]" />
      </div>
    );
  }

  if (!plan) {
    return (
      <div className="min-h-screen bg-[#0B0E17] flex items-center justify-center">
        <Card className="max-w-md">
          <CardContent className="pt-6 text-center">
            <AlertCircle className="w-12 h-12 text-red-400 mx-auto mb-4" />
            <h2 className="text-xl font-bold text-white mb-2">Invalid Plan</h2>
            <p className="text-gray-400 mb-4">The selected plan does not exist.</p>
            <Link href="/pricing"><Button>View Plans</Button></Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (paymentSuccess) {
    return (
      <div className="min-h-screen bg-[#0B0E17] flex items-center justify-center">
        <Card className="max-w-md shadow-2xl shadow-[#14F195]/10">
          <CardContent className="pt-8 text-center">
            <div className="w-20 h-20 bg-[#14F195]/10 rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle className="w-10 h-10 text-[#14F195]" />
            </div>
            <h2 className="text-2xl font-bold text-white mb-2">Payment Successful!</h2>
            <p className="text-gray-400 mb-6">
              {planType === 'per_document'
                ? 'Your document credit has been added.'
                : 'Welcome to OnChainESign Pro! Your account has been upgraded.'}
            </p>
            <div className="flex flex-col gap-3">
              <Link href="/dashboard">
                <Button className="w-full">Go to Dashboard</Button>
              </Link>
              <Link href="/prepare">
                <Button variant="outline" className="w-full">Prepare a Document</Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0B0E17] text-white">
      {/* Header */}
      <header className="bg-[#0B0E17]/95 backdrop-blur-xl border-b border-white/5 py-4">
        <div className="max-w-4xl mx-auto px-6 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <FileSignature className="w-6 h-6 text-[#9945FF]" />
            <span className="font-bold text-lg">OnChainESign</span>
          </Link>
          <div className="flex items-center gap-1 text-xs text-gray-400">
            <Shield className="w-3 h-3 text-[#14F195]" /> Secure Checkout
          </div>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-6 py-10">
        <Link href="/pricing" className="inline-flex items-center gap-1 text-sm text-gray-500 hover:text-[#9945FF] mb-6">
          <ArrowLeft className="w-4 h-4" /> Back to Plans
        </Link>

        <div className="grid md:grid-cols-2 gap-8">
          {/* Order Summary */}
          <Card className="h-fit">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                {plan.icon} Order Summary
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="border-b border-white/10 pb-4 mb-4">
                <h3 className="text-xl font-bold text-white">{plan.name}</h3>
                <div className="flex items-baseline gap-1 mt-1">
                  <span className="text-3xl font-bold gradient-text">{plan.price}</span>
                  <span className="text-gray-500 text-sm">{plan.period}</span>
                </div>
              </div>
              <ul className="space-y-2">
                {plan.features.map((f, i) => (
                  <li key={i} className="flex items-center gap-2 text-sm text-gray-300">
                    <CheckCircle className="w-4 h-4 text-[#14F195] flex-shrink-0" /> {f}
                  </li>
                ))}
              </ul>
              <div className="mt-6 p-3 bg-[#9945FF]/5 border border-[#9945FF]/10 rounded-lg text-xs text-gray-400">
                <Shield className="w-3 h-3 inline mr-1 text-[#9945FF]" />
                Payment processed securely via PayPal. Funds go to OnChainESign.
              </div>
            </CardContent>
          </Card>

          {/* PayPal Payment */}
          <Card>
            <CardHeader>
              <CardTitle className="text-white">Payment</CardTitle>
            </CardHeader>
            <CardContent>
              {error && (
                <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-lg flex items-center gap-2 text-red-400 text-sm mb-4">
                  <AlertCircle className="w-4 h-4" /> {error}
                </div>
              )}

              <p className="text-sm text-gray-400 mb-4">
                Logged in as <strong className="text-gray-200">{session?.user?.email}</strong>
              </p>

              {clientId ? (
                <PayPalScriptProvider options={{
                  clientId,
                  currency: 'USD',
                  intent: 'capture',
                }}>
                  <PayPalButtons
                    style={{
                      layout: 'vertical',
                      color: 'gold',
                      shape: 'rect',
                      label: 'paypal',
                    }}
                    createOrder={async () => {
                      try {
                        const res = await fetch('/api/paypal/create-order', {
                          method: 'POST',
                          headers: { 'Content-Type': 'application/json' },
                          body: JSON.stringify({ planType }),
                        });
                        const data = await res.json();
                        if (!data.success) throw new Error(data.error);
                        return data.orderId;
                      } catch (err: any) {
                        setError(err?.message || 'Failed to create order');
                        throw err;
                      }
                    }}
                    onApprove={async (data) => {
                      try {
                        const res = await fetch('/api/paypal/capture-order', {
                          method: 'POST',
                          headers: { 'Content-Type': 'application/json' },
                          body: JSON.stringify({ orderId: data.orderID, planType }),
                        });
                        const result = await res.json();
                        if (result.success) {
                          setPaymentSuccess(true);
                        } else {
                          setError(result.error || 'Payment capture failed');
                        }
                      } catch (err: any) {
                        setError(err?.message || 'Payment processing failed');
                      }
                    }}
                    onError={(err) => {
                      console.error('PayPal error:', err);
                      setError('Payment could not be processed. Please try again.');
                    }}
                    onCancel={() => {
                      setError('Payment was cancelled.');
                    }}
                  />
                </PayPalScriptProvider>
              ) : (
                <div className="text-center py-8 text-gray-500">
                  <AlertCircle className="w-8 h-8 mx-auto mb-2" />
                  <p className="text-sm">Payment system is being configured.</p>
                </div>
              )}

              <div className="mt-6 text-center">
                <p className="text-xs text-gray-600">By completing this purchase, you agree to our terms of service.</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

export default function CheckoutPage() {
  return (
    <CheckoutContent />
  );
}
