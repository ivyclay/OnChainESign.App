"use client";

import { useSession, signOut } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { useEffect, useState, useCallback } from 'react';
import { FileSignature, LogOut, FileText, Users, Clock, CheckCircle, AlertCircle, Plus, Search, Send, Eye, Loader2, ChevronDown, ChevronUp, Shield, Copy, ExternalLink, Crown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import Link from 'next/link';

interface Doc {
  id: string;
  fileName: string;
  status: string;
  agentName: string;
  agentEmail: string;
  createdAt: string;
  updatedAt: string;
  _count?: { signatures: number; parties: number; fields: number };
  parties?: any[];
}

const STATUS_COLORS: Record<string, string> = {
  draft: 'bg-white/5 text-gray-400 border border-white/10',
  pending: 'bg-yellow-500/10 text-yellow-400 border border-yellow-500/20',
  partially_signed: 'bg-blue-500/10 text-blue-400 border border-blue-500/20',
  signed: 'bg-[#14F195]/10 text-[#14F195] border border-[#14F195]/20',
  completed: 'bg-[#9945FF]/10 text-[#9945FF] border border-[#9945FF]/20',
};

const STATUS_LABELS: Record<string, string> = {
  draft: 'Draft',
  pending: 'Awaiting Signatures',
  partially_signed: 'Partially Signed',
  signed: 'Signed',
  completed: 'Completed',
};

export default function DashboardPage() {
  const { data: session, status } = useSession() || {};
  const router = useRouter();
  const [docs, setDocs] = useState<Doc[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [expandedDoc, setExpandedDoc] = useState<string | null>(null);
  const [inviting, setInviting] = useState<string | null>(null);
  const [inviteResult, setInviteResult] = useState<Record<string, any>>({});

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.replace('/login');
    }
  }, [status, router]);

  const loadDocs = useCallback(async () => {
    try {
      const res = await fetch('/api/dashboard/documents');
      const data = await res.json();
      if (data?.success) setDocs(data.documents);
    } catch {
      console.error('Failed to load documents');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (status === 'authenticated') loadDocs();
  }, [status, loadDocs]);

  const sendInvites = async (docId: string) => {
    setInviting(docId);
    try {
      const res = await fetch('/api/invite', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ documentId: docId, sendEmails: true }),
      });
      const data = await res.json();
      if (data.success) {
        setInviteResult(prev => ({ ...prev, [docId]: { success: true, parties: data.parties } }));
        loadDocs();
      } else {
        setInviteResult(prev => ({ ...prev, [docId]: { error: data.error } }));
      }
    } catch {
      setInviteResult(prev => ({ ...prev, [docId]: { error: 'Failed to send invitations' } }));
    } finally {
      setInviting(null);
    }
  };

  const copyLink = (link: string) => {
    navigator.clipboard.writeText(link);
  };

  const filtered = docs.filter(d => {
    const matchesSearch = !search || d.fileName.toLowerCase().includes(search.toLowerCase()) || d.agentName.toLowerCase().includes(search.toLowerCase());
    const matchesStatus = statusFilter === 'all' || d.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const stats = {
    total: docs.length,
    pending: docs.filter(d => d.status === 'pending' || d.status === 'partially_signed').length,
    signed: docs.filter(d => d.status === 'signed' || d.status === 'completed').length,
    draft: docs.filter(d => d.status === 'draft').length,
  };

  if (status === 'loading' || loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#0B0E17]">
        <Loader2 className="w-8 h-8 animate-spin text-[#9945FF]" />
      </div>
    );
  }

  if (status === 'unauthenticated') return null;

  const plan = (session?.user as any)?.plan || 'free';

  return (
    <main className="min-h-screen bg-[#0B0E17] text-white">
      {/* Header */}
      <header className="bg-[#0B0E17]/95 backdrop-blur-xl border-b border-white/5 text-white py-3 px-4 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <FileSignature className="w-6 h-6 text-[#9945FF]" />
            <span className="font-bold text-lg">OnChainESign</span>
            <div className="hidden sm:flex items-center gap-1 ml-2 opacity-70">
              <img src="/solana-logo.png" alt="Solana" className="h-3.5 w-3.5" />
              <span className="text-xs font-medium bg-gradient-to-r from-[#9945FF] to-[#14F195] bg-clip-text text-transparent">Solana</span>
            </div>
          </Link>
          <div className="flex items-center gap-4">
            {plan !== 'free' && (
              <span className="inline-flex items-center gap-1 bg-[#9945FF]/15 text-[#9945FF] px-3 py-1 rounded-full text-xs font-medium border border-[#9945FF]/20">
                <Crown className="w-3 h-3" /> {plan.toUpperCase()}
              </span>
            )}
            <span className="text-sm text-gray-400 hidden sm:block">{session?.user?.email}</span>
            <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white hover:bg-white/5" onClick={() => signOut({ callbackUrl: '/' })}>
              <LogOut className="w-4 h-4 mr-1" /> Sign Out
            </Button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto p-4 sm:p-6">
        {/* Welcome */}
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-white">Welcome, {session?.user?.name}</h1>
          <p className="text-gray-500 text-sm">Manage your documents and track signatures</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <Card className="cursor-pointer hover:border-[#9945FF]/30 transition-colors" onClick={() => setStatusFilter('all')}>
            <CardContent className="pt-4 pb-3 flex items-center gap-3">
              <div className="w-10 h-10 bg-[#9945FF]/10 rounded-full flex items-center justify-center">
                <FileText className="w-5 h-5 text-[#9945FF]" />
              </div>
              <div>
                <p className="text-2xl font-bold text-white">{stats.total}</p>
                <p className="text-xs text-gray-500">Total</p>
              </div>
            </CardContent>
          </Card>
          <Card className="cursor-pointer hover:border-yellow-500/30 transition-colors" onClick={() => setStatusFilter('pending')}>
            <CardContent className="pt-4 pb-3 flex items-center gap-3">
              <div className="w-10 h-10 bg-yellow-500/10 rounded-full flex items-center justify-center">
                <Clock className="w-5 h-5 text-yellow-400" />
              </div>
              <div>
                <p className="text-2xl font-bold text-yellow-400">{stats.pending}</p>
                <p className="text-xs text-gray-500">Pending</p>
              </div>
            </CardContent>
          </Card>
          <Card className="cursor-pointer hover:border-[#14F195]/30 transition-colors" onClick={() => setStatusFilter('signed')}>
            <CardContent className="pt-4 pb-3 flex items-center gap-3">
              <div className="w-10 h-10 bg-[#14F195]/10 rounded-full flex items-center justify-center">
                <CheckCircle className="w-5 h-5 text-[#14F195]" />
              </div>
              <div>
                <p className="text-2xl font-bold text-[#14F195]">{stats.signed}</p>
                <p className="text-xs text-gray-500">Signed</p>
              </div>
            </CardContent>
          </Card>
          <Card className="cursor-pointer hover:border-white/20 transition-colors" onClick={() => setStatusFilter('draft')}>
            <CardContent className="pt-4 pb-3 flex items-center gap-3">
              <div className="w-10 h-10 bg-white/5 rounded-full flex items-center justify-center">
                <AlertCircle className="w-5 h-5 text-gray-400" />
              </div>
              <div>
                <p className="text-2xl font-bold text-gray-300">{stats.draft}</p>
                <p className="text-xs text-gray-500">Drafts</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Actions + Search */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 mb-4">
          <div className="flex items-center gap-2 flex-1 w-full sm:w-auto">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
              <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search documents..." className="pl-9" />
            </div>
            <select value={statusFilter} onChange={e => setStatusFilter(e.target.value)} className="bg-[#0f1225] border border-[#2a2d45] rounded-lg px-3 py-2 text-sm text-gray-300 focus:border-[#9945FF] focus:outline-none">
              <option value="all">All Status</option>
              <option value="draft">Draft</option>
              <option value="pending">Pending</option>
              <option value="partially_signed">Partially Signed</option>
              <option value="signed">Signed</option>
              <option value="completed">Completed</option>
            </select>
          </div>
          <Link href="/prepare">
            <Button className="w-full sm:w-auto">
              <Plus className="w-4 h-4 mr-2" /> New Document
            </Button>
          </Link>
        </div>

        {/* Document List */}
        {filtered.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center">
              <FileText className="w-12 h-12 text-gray-600 mx-auto mb-3" />
              <p className="text-gray-500">{docs.length === 0 ? 'No documents yet. Create your first one!' : 'No matching documents.'}</p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-3">
            {filtered.map(doc => (
              <Card key={doc.id} className="hover:border-[#9945FF]/20 transition-colors">
                <CardContent className="py-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-semibold text-white truncate">{doc.fileName}</h3>
                        <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${STATUS_COLORS[doc.status] || 'bg-white/5'}`}>
                          {STATUS_LABELS[doc.status] || doc.status}
                        </span>
                      </div>
                      <div className="flex items-center gap-4 text-xs text-gray-500">
                        <span>By: {doc.agentName}</span>
                        <span>{doc._count?.parties || 0} parties</span>
                        <span>{doc._count?.signatures || 0} signatures</span>
                        <span>{new Date(doc.createdAt).toLocaleDateString()}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 flex-shrink-0">
                      {(doc.status === 'pending' || doc.status === 'partially_signed') && (doc._count?.parties || 0) > 0 && (
                        <Button size="sm" variant="outline" className="text-xs" onClick={() => sendInvites(doc.id)} disabled={inviting === doc.id}>
                          {inviting === doc.id ? <Loader2 className="w-3 h-3 animate-spin mr-1" /> : <Send className="w-3 h-3 mr-1" />}
                          Send Invites
                        </Button>
                      )}
                      <Link href={`/document/${doc.id}`}>
                        <Button size="sm" variant="outline" className="text-xs"><Eye className="w-3 h-3 mr-1" /> View</Button>
                      </Link>
                      <button onClick={() => setExpandedDoc(expandedDoc === doc.id ? null : doc.id)} className="text-gray-500 hover:text-gray-300">
                        {expandedDoc === doc.id ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>

                  {/* Expanded details */}
                  {expandedDoc === doc.id && (
                    <div className="mt-4 pt-4 border-t border-white/5 space-y-3">
                      {doc.parties && doc.parties.length > 0 && (
                        <div>
                          <p className="text-xs font-medium text-gray-500 mb-2">Parties & Signing Status:</p>
                          <div className="space-y-2">
                            {doc.parties.map((p: any) => (
                              <div key={p.id} className="flex items-center justify-between bg-white/[0.03] rounded-lg px-3 py-2">
                                <div className="flex items-center gap-2">
                                  <span className={`w-2 h-2 rounded-full ${p.signedAt ? 'bg-[#14F195]' : p.status === 'sent' ? 'bg-blue-400' : p.status === 'viewed' ? 'bg-yellow-400' : 'bg-gray-600'}`} />
                                  <span className="text-sm font-medium text-gray-200">{p.name}</span>
                                  <span className="text-xs text-gray-500">({p.role})</span>
                                  <span className="text-xs text-gray-500">{p.email}</span>
                                </div>
                                <div className="flex items-center gap-2">
                                  <span className={`text-xs px-2 py-0.5 rounded-full ${p.signedAt ? 'bg-[#14F195]/10 text-[#14F195]' : p.status === 'sent' ? 'bg-blue-500/10 text-blue-400' : p.status === 'viewed' ? 'bg-yellow-500/10 text-yellow-400' : 'bg-white/5 text-gray-500'}`}>
                                    {p.signedAt ? 'Signed' : p.status === 'sent' ? 'Invited' : p.status === 'viewed' ? 'Viewed' : 'Pending'}
                                  </span>
                                  {p.signingToken && (
                                    <button onClick={() => copyLink(`${window.location.origin}/sign/party/${p.signingToken}`)} className="text-gray-500 hover:text-[#9945FF]" title="Copy signing link">
                                      <Copy className="w-3 h-3" />
                                    </button>
                                  )}
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                      {inviteResult[doc.id]?.success && (
                        <div className="bg-[#14F195]/10 text-[#14F195] border border-[#14F195]/20 px-3 py-2 rounded-lg text-xs">
                          Invitations sent successfully to all parties!
                        </div>
                      )}
                      {inviteResult[doc.id]?.error && (
                        <div className="bg-red-500/10 text-red-400 border border-red-500/20 px-3 py-2 rounded-lg text-xs">
                          {inviteResult[doc.id].error}
                        </div>
                      )}
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Plan info */}
        {plan === 'free' && (
          <div className="mt-8 glass-card rounded-xl p-6 border-[#9945FF]/20 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-[#9945FF]/5 to-[#14F195]/5" />
            <div className="flex items-center justify-between flex-wrap gap-4 relative z-10">
              <div>
                <h3 className="text-lg font-bold text-white">Upgrade to Pro</h3>
                <p className="text-gray-400 text-sm">Unlimited documents, priority blockchain minting, and email invitations.</p>
              </div>
              <Link href="/pricing">
                <Button>
                  <Crown className="w-4 h-4 mr-2" /> View Plans
                </Button>
              </Link>
            </div>
          </div>
        )}
      </div>
    </main>
  );
}
