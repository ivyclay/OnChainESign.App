import { FileSignature, Shield } from 'lucide-react';
import Link from 'next/link';
import { PartySignerView } from './party-signer-view';

export default function PartySignPage({ params }: { params: { token: string } }) {
  return (
    <main className="min-h-screen bg-[#0B0E17]">
      <header className="bg-[#0B0E17]/95 backdrop-blur-xl border-b border-white/5 text-white py-3 px-4 sticky top-0 z-50">
        <div className="max-w-5xl mx-auto flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <FileSignature className="w-6 h-6 text-[#9945FF]" />
            <span className="font-bold text-white">OnChainESign</span>
          </Link>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5">
              <img src="/solana-logo.png" alt="Solana" className="h-4 w-4" />
              <span className="text-xs font-medium bg-gradient-to-r from-[#9945FF] to-[#14F195] bg-clip-text text-transparent">Solana</span>
            </div>
            <div className="flex items-center gap-1 text-xs text-gray-400">
              <Shield className="w-3.5 h-3.5 text-[#14F195]" />
              <span>Legally Binding</span>
            </div>
          </div>
        </div>
      </header>
      <PartySignerView token={params.token} />
    </main>
  );
}
