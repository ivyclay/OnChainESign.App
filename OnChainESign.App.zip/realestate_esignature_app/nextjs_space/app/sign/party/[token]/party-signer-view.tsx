"use client";

import { useState, useEffect, useCallback } from 'react';
import { User, FileCheck, Pen, CheckCircle, ArrowRight, ArrowLeft, Loader2, Shield, AlertCircle, Download, ExternalLink } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { PdfViewer } from '@/components/pdf-viewer';
import { FieldOverlay } from '@/components/field-overlay';
import { SignatureCanvas } from '@/components/signature-canvas';
import { TypedSignature } from '@/components/typed-signature';
import type { FieldData } from '@/lib/types';

type Step = 'loading' | 'consent' | 'fill' | 'complete' | 'already_signed' | 'error';
type SigMethod = 'draw' | 'type';

interface Props { token: string; }

export function PartySignerView({ token }: Props) {
  const [step, setStep] = useState<Step>('loading');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [partyInfo, setPartyInfo] = useState<any>(null);
  const [docInfo, setDocInfo] = useState<any>(null);
  const [docUrl, setDocUrl] = useState('');
  const [fields, setFields] = useState<FieldData[]>([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(0);
  const [consentGiven, setConsentGiven] = useState(false);
  const [intentConfirmed, setIntentConfirmed] = useState(false);
  const [uetaAck, setUetaAck] = useState(false);
  const [activeFieldIdx, setActiveFieldIdx] = useState<number | null>(null);
  const [sigMethod, setSigMethod] = useState<SigMethod>('type');
  const [signatureData, setSignatureData] = useState('');
  const [signResult, setSignResult] = useState<any>(null);
  const [blockchainResult, setBlockchainResult] = useState<any>(null);
  const [minting, setMinting] = useState(false);
  const [allParties, setAllParties] = useState<any[]>([]);

  useEffect(() => {
    const load = async () => {
      try {
        const res = await fetch(`/api/sign/party?token=${token}`);
        const data = await res.json();
        if (!data.success) {
          setError(data.error || 'Invalid signing link');
          setStep('error');
          return;
        }
        setPartyInfo(data.party);
        setDocInfo(data.document);
        setDocUrl(data.documentUrl);
        setAllParties(data.allParties || []);
        if (data.party.signedAt) {
          setStep('already_signed');
          return;
        }
        setFields(data.fields.map((f: any) => ({
          id: f.id,
          fieldType: f.fieldType,
          pageNumber: f.pageNumber,
          xPercent: f.xPercent,
          yPercent: f.yPercent,
          widthPercent: f.widthPercent,
          heightPercent: f.heightPercent,
          label: f.label,
          required: f.required,
          value: f.value || undefined,
        })));
        setStep('consent');
      } catch {
        setError('Failed to load document');
        setStep('error');
      }
    };
    load();
  }, [token]);

  const handleSigChange = useCallback((data: string) => setSignatureData(data), []);

  const applyToField = (fieldIdx: number) => {
    const field = fields[fieldIdx];
    if (!field) return;
    let value = '';
    if (field.fieldType === 'signature' || field.fieldType === 'initials') {
      if (!signatureData) { setError('Please create your signature first'); return; }
      value = signatureData;
    } else if (field.fieldType === 'date') {
      value = new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
    } else if (field.fieldType === 'text') {
      value = partyInfo?.name || 'Text';
    }
    setFields(prev => prev.map((f, i) => i === fieldIdx ? { ...f, value } : f));
    setActiveFieldIdx(null);
    setError('');
  };

  const allFilled = fields.every(f => !!f.value);

  const submitSigning = async () => {
    if (!allFilled) { setError('Please fill all required fields'); return; }
    setLoading(true);
    setError('');
    try {
      const fieldValues = fields.map(f => ({ id: f.id, value: f.value }));
      const res = await fetch('/api/sign/party', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          token,
          fieldValues,
          signatureType: sigMethod,
          signatureData,
          consentGiven,
          intentConfirmed,
        }),
      });
      const data = await res.json();
      if (!data?.success) throw new Error(data?.error || 'Signing failed');
      setSignResult(data);
      setStep('complete');
    } catch (err: any) {
      setError(err?.message || 'Signing failed');
    } finally {
      setLoading(false);
    }
  };

  const mintToBlockchain = async () => {
    if (!docInfo?.id) return;
    setMinting(true);
    try {
      const res = await fetch('/api/blockchain', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ documentId: docInfo.id }),
      });
      const data = await res.json();
      if (data?.success) setBlockchainResult(data);
      else setError(data?.error || 'Blockchain minting failed');
    } catch (err: any) {
      setError(err?.message || 'Blockchain minting failed');
    } finally {
      setMinting(false);
    }
  };

  const pageFields = fields.filter(f => f.pageNumber === currentPage);

  if (step === 'loading') {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 className="w-8 h-8 animate-spin text-[#9945FF]" />
      </div>
    );
  }

  if (step === 'error') {
    return (
      <div className="max-w-md mx-auto p-6 mt-12">
        <Card><CardContent className="pt-6 text-center">
          <AlertCircle className="w-12 h-12 text-red-400 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-white">Cannot Access Document</h2>
          <p className="text-gray-500 mt-2">{error || 'This signing link may be invalid or expired.'}</p>
        </CardContent></Card>
      </div>
    );
  }

  if (step === 'already_signed') {
    return (
      <div className="max-w-md mx-auto p-6 mt-12">
        <Card className="shadow-lg"><CardContent className="pt-6 text-center">
          <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-[#9945FF]">Already Signed</h2>
          <p className="text-gray-500 mt-2">You have already signed this document as <strong>{partyInfo?.role}</strong>.</p>
          <p className="text-gray-400 text-sm mt-1">Signed on: {partyInfo?.signedAt ? new Date(partyInfo.signedAt).toLocaleString() : 'N/A'}</p>
        </CardContent></Card>
      </div>
    );
  }

  // Consent step
  if (step === 'consent') {
    return (
      <div className="max-w-lg mx-auto p-6 mt-8">
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-[#9945FF]"><Shield className="w-5 h-5" /> ESIGN Act & UETA Compliance</CardTitle>
            <CardDescription>Review and consent before signing</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <p className="text-sm text-gray-300"><strong>Document:</strong> {docInfo?.fileName}</p>
              <p className="text-sm text-gray-300"><strong>From:</strong> {docInfo?.agentName}</p>
              <p className="text-sm text-gray-300"><strong>Your Role:</strong> {partyInfo?.role}</p>
              <p className="text-sm text-gray-300"><strong>Your Name:</strong> {partyInfo?.name}</p>
            </div>
            {allParties.length > 1 && (
              <div className="bg-[#0f1225] rounded-lg p-3">
                <p className="text-xs font-medium text-gray-500 mb-2">All Parties to This Document:</p>
                {allParties.map((p: any, i: number) => (
                  <div key={i} className="flex items-center gap-2 text-xs py-1">
                    <span className={`w-2 h-2 rounded-full ${p.signedAt ? 'bg-[#14F195]/100' : p.id === partyInfo?.id ? 'bg-blue-500' : 'bg-gray-300'}`} />
                    <span className="text-gray-300">{p.name} ({p.role})</span>
                    {p.signedAt && <span className="text-green-600">Signed</span>}
                    {p.id === partyInfo?.id && !p.signedAt && <span className="text-blue-600 font-medium">You</span>}
                  </div>
                ))}
              </div>
            )}
            <div className="space-y-3">
              <label className="flex items-start gap-3 cursor-pointer">
                <input type="checkbox" checked={consentGiven} onChange={e => setConsentGiven(e.target.checked)} className="mt-1 w-4 h-4 rounded" />
                <span className="text-sm text-gray-300">I consent to use electronic signatures and records for this transaction per the ESIGN Act (15 U.S.C. §§ 7001-7006).</span>
              </label>
              <label className="flex items-start gap-3 cursor-pointer">
                <input type="checkbox" checked={intentConfirmed} onChange={e => setIntentConfirmed(e.target.checked)} className="mt-1 w-4 h-4 rounded" />
                <span className="text-sm text-gray-300">I intend to sign this document electronically with the same legal effect as a handwritten signature.</span>
              </label>
              <label className="flex items-start gap-3 cursor-pointer">
                <input type="checkbox" checked={uetaAck} onChange={e => setUetaAck(e.target.checked)} className="mt-1 w-4 h-4 rounded" />
                <span className="text-sm text-gray-300">I acknowledge that this electronic signature is verified on the Solana blockchain for immutability.</span>
              </label>
            </div>
            {error && <p className="text-red-500 text-sm">{error}</p>}
            <Button
              onClick={() => { if (consentGiven && intentConfirmed && uetaAck) setStep('fill'); else setError('Please check all consent boxes'); }}
              className="w-full bg-[#9945FF] hover:bg-[#7c35e0]"
              disabled={!consentGiven || !intentConfirmed || !uetaAck}
            >
              Continue to Sign <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Fill step
  if (step === 'fill') {
    return (
      <div className="max-w-5xl mx-auto p-4">
        <div className="mb-4 flex items-center justify-between flex-wrap gap-3">
          <div>
            <h2 className="text-lg font-bold text-[#9945FF]">Sign: {docInfo?.fileName}</h2>
            <p className="text-sm text-gray-500">Signing as {partyInfo?.name} ({partyInfo?.role})</p>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs text-gray-500">{fields.filter(f => !!f.value).length}/{fields.length} fields filled</span>
            <Button onClick={submitSigning} disabled={!allFilled || loading} className="bg-green-600 hover:bg-green-700">
              {loading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Pen className="w-4 h-4 mr-2" />}
              Complete Signing
            </Button>
          </div>
        </div>
        {error && <div className="bg-red-50 text-red-600 px-4 py-2 rounded-lg text-sm mb-4">{error}</div>}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <div className="lg:col-span-2">
            <div className="bg-white rounded-xl shadow-md overflow-hidden">
              <div className="relative">
                <PdfViewer url={docUrl} currentPage={currentPage} onPageChange={setCurrentPage} onTotalPagesChange={setTotalPages}>
                  {pageFields.map((field, idx) => {
                    const globalIdx = fields.findIndex(f => f === field);
                    return (
                      <FieldOverlay
                        key={idx}
                        field={field}
                        isActive={activeFieldIdx === globalIdx}
                        onClick={() => setActiveFieldIdx(globalIdx)}
                      />
                    );
                  })}
                </PdfViewer>
              </div>
              {totalPages > 1 && (
                <div className="flex items-center justify-center gap-4 py-3 bg-[#0f1225]">
                  <Button size="sm" variant="outline" onClick={() => setCurrentPage(p => Math.max(1, p - 1))} disabled={currentPage <= 1}>
                    <ArrowLeft className="w-4 h-4" />
                  </Button>
                  <span className="text-sm text-gray-400">Page {currentPage} of {totalPages}</span>
                  <Button size="sm" variant="outline" onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))} disabled={currentPage >= totalPages}>
                    <ArrowRight className="w-4 h-4" />
                  </Button>
                </div>
              )}
            </div>
          </div>
          <div className="space-y-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm">Your Signature</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex gap-2 mb-3">
                  <button onClick={() => setSigMethod('type')} className={`px-3 py-1 text-xs rounded-full ${sigMethod === 'type' ? 'bg-[#9945FF] text-white' : 'bg-gray-100 text-gray-400'}`}>Type</button>
                  <button onClick={() => setSigMethod('draw')} className={`px-3 py-1 text-xs rounded-full ${sigMethod === 'draw' ? 'bg-[#9945FF] text-white' : 'bg-gray-100 text-gray-400'}`}>Draw</button>
                </div>
                {sigMethod === 'type' ? (
                  <TypedSignature onSignatureChange={handleSigChange} />
                ) : (
                  <SignatureCanvas onSignatureChange={handleSigChange} />
                )}
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm">Fields to Fill ({fields.filter(f => !!f.value).length}/{fields.length})</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 max-h-60 overflow-y-auto">
                  {fields.map((f, i) => (
                    <div key={i} className={`flex items-center justify-between p-2 rounded-lg text-xs cursor-pointer transition-colors ${f.value ? 'bg-[#14F195]/10 border border-green-200' : activeFieldIdx === i ? 'bg-blue-50 border border-blue-500/30' : 'bg-[#0f1225] border border-white/10 hover:bg-blue-50'}`}
                      onClick={() => { setActiveFieldIdx(i); setCurrentPage(f.pageNumber); }}
                    >
                      <span className="font-medium capitalize">{f.fieldType} (p.{f.pageNumber})</span>
                      {f.value ? (
                        <CheckCircle className="w-4 h-4 text-green-500" />
                      ) : (
                        <Button size="sm" variant="outline" className="h-6 text-xs" onClick={(e) => { e.stopPropagation(); applyToField(i); }}>Apply</Button>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  // Complete step
  return (
    <div className="max-w-lg mx-auto p-6 mt-8">
      <Card className="shadow-lg">
        <CardContent className="pt-8 text-center">
          <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-[#9945FF] mb-2">Signing Complete!</h2>
          <p className="text-gray-500 mb-2">You have successfully signed as <strong>{partyInfo?.role}</strong>.</p>
          {signResult?.remainingParties > 0 && (
            <p className="text-sm text-amber-400 bg-amber-500/10 px-3 py-2 rounded-lg mb-4">
              {signResult.remainingParties} other {signResult.remainingParties === 1 ? 'party' : 'parties'} still need to sign.
            </p>
          )}
          {signResult?.remainingParties === 0 && (
            <p className="text-sm text-green-600 bg-[#14F195]/10 px-3 py-2 rounded-lg mb-4">
              All parties have signed! The document is fully executed.
            </p>
          )}
          <div className="bg-[#0f1225] rounded-lg p-4 text-left text-sm space-y-1 mb-6">
            <p><strong>Hash:</strong> <code className="text-xs break-all">{signResult?.signature?.signatureHash}</code></p>
            <p><strong>Signed:</strong> {signResult?.signature?.signedAt ? new Date(signResult.signature.signedAt).toLocaleString() : 'N/A'}</p>
          </div>
          {!blockchainResult && (
            <Button onClick={mintToBlockchain} disabled={minting} className="w-full bg-purple-600 hover:bg-purple-700 mb-3">
              {minting ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <ExternalLink className="w-4 h-4 mr-2" />}
              Mint to Solana Blockchain
            </Button>
          )}
          {blockchainResult && (
            <div className="bg-purple-50 border border-purple-200 rounded-lg p-3 text-left text-sm mb-3">
              <p className="font-medium text-purple-800">Minted on Solana!</p>
              <p className="text-xs text-purple-600 break-all mt-1">TX: {blockchainResult.txHash}</p>
            </div>
          )}
          <p className="text-xs text-gray-400 mt-4">ESIGN Act & UETA Compliant · Blockchain Verified</p>
        </CardContent>
      </Card>
    </div>
  );
}
