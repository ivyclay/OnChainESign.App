import { FileSignature, Shield } from 'lucide-react';
import Link from 'next/link';
import { SignerView } from './signer-view';

export default function SignDocumentPage({ params }: { params: { id: string } }) {
  return (
    <main className="min-h-screen bg-[#0B0E17]">
      <header className="bg-[#0B0E17]/95 backdrop-blur-xl border-b border-white/5 text-white py-3 px-4 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <FileSignature className="w-6 h-6 text-[#9945FF]" />
            <span className="font-bold text-white">OnChainESign</span>
          </Link>
          <div className="flex items-center gap-2 text-xs text-gray-400">
            <Shield className="w-4 h-4 text-[#14F195]" />
            <span>Blockchain Verified · Legally Binding</span>
          </div>
        </div>
      </header>
      <SignerView documentId={params.id} />
    </main>
  );
}
