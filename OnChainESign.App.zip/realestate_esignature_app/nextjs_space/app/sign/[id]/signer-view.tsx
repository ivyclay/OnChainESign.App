"use client";

import { useState, useEffect, useCallback } from 'react';
import { User, FileCheck, Pen, CheckCircle, ArrowRight, ArrowLeft, Loader2, Shield, AlertCircle, Download, ExternalLink, Link2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { PdfViewer } from '@/components/pdf-viewer';
import { FieldOverlay } from '@/components/field-overlay';
import { SignatureCanvas } from '@/components/signature-canvas';
import { TypedSignature } from '@/components/typed-signature';
import type { FieldData } from '@/lib/types';

type Step = 'info' | 'consent' | 'fill' | 'complete';
type SigMethod = 'draw' | 'type';

interface Props {
  documentId: string;
}

export function SignerView({ documentId }: Props) {
  const [step, setStep] = useState<Step>('info');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [docInfo, setDocInfo] = useState<any>(null);
  const [docUrl, setDocUrl] = useState('');
  const [fields, setFields] = useState<FieldData[]>([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(0);
  const [signerName, setSignerName] = useState('');
  const [signerEmail, setSignerEmail] = useState('');
  const [signerRole, setSignerRole] = useState<string>('client');
  const [consentGiven, setConsentGiven] = useState(false);
  const [intentConfirmed, setIntentConfirmed] = useState(false);
  const [uetaAck, setUetaAck] = useState(false);
  const [activeFieldIdx, setActiveFieldIdx] = useState<number | null>(null);
  const [sigMethod, setSigMethod] = useState<SigMethod>('type');
  const [signatureData, setSignatureData] = useState('');
  const [signResult, setSignResult] = useState<any>(null);
  const [blockchainResult, setBlockchainResult] = useState<any>(null);
  const [minting, setMinting] = useState(false);

  // Load document and fields
  useEffect(() => {
    const load = async () => {
      try {
        const [docRes, fieldRes, urlRes] = await Promise.all([
          fetch(`/api/documents?id=${documentId}`),
          fetch(`/api/fields?documentId=${documentId}`),
          fetch(`/api/documents/${documentId}/url`),
        ]);
        const docData = await docRes.json();
        const fieldData = await fieldRes.json();
        const urlData = await urlRes.json();

        if (docData?.success) setDocInfo(docData.document);
        if (fieldData?.success) {
          setFields(fieldData.fields.map((f: any) => ({
            id: f.id,
            fieldType: f.fieldType,
            pageNumber: f.pageNumber,
            xPercent: f.xPercent,
            yPercent: f.yPercent,
            widthPercent: f.widthPercent,
            heightPercent: f.heightPercent,
            label: f.label,
            required: f.required,
            value: f.value || undefined,
          })));
        }
        if (urlData?.success) setDocUrl(urlData.url);
      } catch (err) {
        setError('Failed to load document');
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [documentId]);

  const handleSigChange = useCallback((data: string) => setSignatureData(data), []);

  const applyToField = (fieldIdx: number) => {
    const field = fields[fieldIdx];
    if (!field) return;

    let value = '';
    if (field.fieldType === 'signature') {
      if (!signatureData) { setError('Please create your signature first'); return; }
      value = signatureData;
    } else if (field.fieldType === 'initials') {
      if (!signatureData) { setError('Please create your signature/initials first'); return; }
      value = signatureData;
    } else if (field.fieldType === 'date') {
      value = new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
    } else if (field.fieldType === 'text') {
      value = signerName || 'Text';
    }

    setFields(prev => prev.map((f, i) => i === fieldIdx ? { ...f, value } : f));
    setActiveFieldIdx(null);
    setError('');
  };

  const allFilled = fields.every(f => !!f.value);

  const submitSigning = async () => {
    if (!allFilled) { setError('Please fill all required fields'); return; }
    setLoading(true);
    setError('');
    try {
      const fieldValues = fields.map(f => ({ id: f.id, value: f.value }));
      const res = await fetch('/api/fields/fill', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          documentId,
          fieldValues,
          signerName,
          signerEmail,
          signerRole,
          signatureType: sigMethod,
          signatureData,
          consentGiven,
          intentConfirmed,
        }),
      });
      const data = await res.json();
      if (!data?.success) throw new Error(data?.error || 'Signing failed');
      setSignResult(data.signature);

      // Send notification
      await fetch('/api/notify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ signatureId: data.signature.id, documentId }),
      }).catch(() => {});

      setStep('complete');
    } catch (err: any) {
      setError(err?.message || 'Signing failed');
    } finally {
      setLoading(false);
    }
  };

  const mintToBlockchain = async () => {
    setMinting(true);
    try {
      const res = await fetch('/api/blockchain', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ documentId }),
      });
      const data = await res.json();
      if (data?.success) setBlockchainResult(data);
      else setError(data?.error || 'Blockchain minting failed. Wallet may need SOL funding.');
    } catch (err: any) {
      setError(err?.message || 'Blockchain minting failed');
    } finally {
      setMinting(false);
    }
  };

  const downloadCertificate = () => {
    if (!signResult?.id) return;
    const link = document.createElement('a');
    link.href = `/api/certificate?signatureId=${signResult.id}&format=pdf`;
    link.download = `certificate-${signResult.id}.pdf`;
    link.click();
  };

  if (loading && !docInfo) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 className="w-8 h-8 animate-spin text-[#9945FF]" />
      </div>
    );
  }

  if (!docInfo) {
    return (
      <div className="max-w-md mx-auto p-6 mt-12">
        <Card><CardContent className="pt-6 text-center">
          <AlertCircle className="w-12 h-12 text-red-400 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-white">Document Not Found</h2>
          <p className="text-gray-500 mt-2">This signing link may be invalid or expired.</p>
        </CardContent></Card>
      </div>
    );
  }

  // Info step
  if (step === 'info') {
    return (
      <div className="max-w-lg mx-auto p-6">
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-[#9945FF]"><User className="w-5 h-5" /> Your Information</CardTitle>
            <CardDescription>You are signing: <strong>{docInfo.fileName}</strong></CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {error && <p className="text-sm text-red-500">{error}</p>}
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">Full Legal Name *</label>
              <Input value={signerName} onChange={e => setSignerName(e.target.value)} placeholder="Enter full legal name" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">Email *</label>
              <Input type="email" value={signerEmail} onChange={e => setSignerEmail(e.target.value)} placeholder="your@email.com" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">Role</label>
              <div className="grid grid-cols-3 gap-2">
                {['broker', 'agent', 'client'].map(r => (
                  <button key={r} onClick={() => setSignerRole(r)}
                    className={`p-2 rounded border-2 text-sm capitalize font-medium ${signerRole === r ? 'border-[#9945FF] bg-[#9945FF]/10 text-[#9945FF]' : 'border-white/10 text-gray-400'}`}>
                    {r}
                  </button>
                ))}
              </div>
            </div>
            <Button onClick={() => { if (!signerName || !signerEmail) { setError('Fill all fields'); return; } setError(''); setStep('consent'); }}
              disabled={!signerName || !signerEmail} className="w-full bg-[#9945FF] hover:bg-[#7c35e0]">
              Continue <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Consent step
  if (step === 'consent') {
    return (
      <div className="max-w-lg mx-auto p-6">
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-[#9945FF]"><FileCheck className="w-5 h-5" /> Legal Consent</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="bg-amber-500/10 border border-amber-500/20 rounded-lg p-3">
              <div className="flex items-start gap-2">
                <Shield className="w-5 h-5 text-amber-400 mt-0.5" />
                <div>
                  <h4 className="font-semibold text-amber-300 text-sm">ESIGN Act & UETA Compliance</h4>
                  <p className="text-xs text-amber-400/80 mt-1">Compliant with the U.S. ESIGN Act (15 U.S.C. §7001), UETA, EU eIDAS Regulation, UK Electronic Communications Act 2000, and applicable international e-signature laws. Electronic signatures carry the same legal effect as handwritten signatures. Blockchain-verified for immutability. You may withdraw consent to use electronic signatures at any time by contacting the document sender.</p>
                </div>
              </div>
            </div>
            {[{ checked: consentGiven, set: setConsentGiven, title: 'Consent to Electronic Signing', desc: 'I consent to signing electronically and understand it has the same legal effect as a handwritten signature.' },
              { checked: intentConfirmed, set: setIntentConfirmed, title: 'Intent to Sign', desc: `I confirm my intent to sign "${docInfo.fileName}" and create a legally binding agreement.` },
              { checked: uetaAck, set: setUetaAck, title: 'Record Retention Acknowledgment', desc: 'I understand an audit trail including my identity, timestamp, IP address, and blockchain hash will be recorded.' },
            ].map((item, i) => (
              <label key={i} className="flex items-start gap-3 p-3 border rounded-lg hover:bg-[#0f1225] cursor-pointer">
                <input type="checkbox" checked={item.checked} onChange={e => item.set(e.target.checked)} className="mt-1 w-4 h-4" />
                <div><span className="font-medium text-white text-sm">{item.title} *</span><p className="text-xs text-gray-400 mt-0.5">{item.desc}</p></div>
              </label>
            ))}
            <div className="flex gap-3">
              <Button variant="outline" onClick={() => setStep('info')}><ArrowLeft className="w-4 h-4 mr-1" /> Back</Button>
              <Button onClick={() => { if (!consentGiven || !intentConfirmed || !uetaAck) { setError('Accept all'); return; } setError(''); setStep('fill'); }}
                disabled={!consentGiven || !intentConfirmed || !uetaAck} className="flex-1 bg-[#9945FF] hover:bg-[#7c35e0]">
                Proceed to Sign <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Complete step
  if (step === 'complete') {
    return (
      <div className="max-w-2xl mx-auto p-6">
        <Card className="shadow-lg">
          <CardContent className="pt-8 text-center">
            <div className="w-16 h-16 bg-[#14F195]/10 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="w-8 h-8 text-green-600" />
            </div>
            <h2 className="text-2xl font-bold text-[#9945FF] mb-2">Document Signed!</h2>
            <p className="text-gray-400 mb-4">Your signature has been recorded and verified.</p>

            <div className="bg-[#0f1225] rounded-lg p-4 text-left text-sm space-y-2 mb-4">
              <div className="flex justify-between"><span className="text-gray-500">Document:</span><span className="font-medium">{docInfo.fileName}</span></div>
              <div className="flex justify-between"><span className="text-gray-500">Signed by:</span><span className="font-medium">{signerName}</span></div>
              <div className="flex justify-between"><span className="text-gray-500">Hash:</span><span className="font-mono text-xs">{signResult?.signatureHash?.slice(0, 24)}...</span></div>
            </div>

            {/* Blockchain section */}
            {!blockchainResult ? (
              <Button onClick={mintToBlockchain} disabled={minting} className="w-full mb-4 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white">
                {minting ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Minting to Solana...</> : <><Link2 className="w-4 h-4 mr-2" /> Mint to Solana Blockchain</>}
              </Button>
            ) : (
              <div className="bg-purple-50 border border-purple-200 rounded-lg p-4 mb-4 text-left">
                <h4 className="font-semibold text-purple-800 text-sm mb-2">⛓️ Blockchain Verified</h4>
                <p className="text-xs text-purple-700 font-mono break-all mb-2">TX: {blockchainResult.txHash}</p>
                <a href={blockchainResult.explorerUrl} target="_blank" rel="noopener noreferrer"
                  className="text-xs text-purple-600 hover:text-purple-800 flex items-center gap-1">
                  <ExternalLink className="w-3 h-3" /> View on Solana Explorer
                </a>
              </div>
            )}

            {error && <p className="text-sm text-red-500 mb-4">{error}</p>}

            <div className="flex gap-3">
              <Button onClick={downloadCertificate} className="flex-1 bg-[#9945FF] hover:bg-[#7c35e0]">
                <Download className="w-4 h-4 mr-2" /> Certificate
              </Button>
              <Button onClick={() => window.location.href = `/document/${documentId}`} variant="outline" className="flex-1">
                View Document
              </Button>
            </div>

            <div className="mt-4 p-3 bg-green-50 border border-green-200 rounded-lg">
              <p className="text-xs text-green-800 flex items-center justify-center gap-2">
                <Shield className="w-3 h-3" /> ESIGN Act & UETA Compliant · Blockchain-Verified Electronic Signature
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Fill step - main signing interface
  const pageFields = fields.filter(f => f.pageNumber === currentPage);
  const filledCount = fields.filter(f => !!f.value).length;

  return (
    <div className="max-w-7xl mx-auto p-4">
      <div className="flex flex-col lg:flex-row gap-4">
        {/* Left panel - Signature tools */}
        <div className="lg:w-72 flex-shrink-0">
          <Card className="shadow-lg sticky top-4">
            <CardHeader className="pb-2">
              <CardTitle className="text-base text-[#9945FF]">Sign Document</CardTitle>
              <CardDescription className="text-xs">{filledCount}/{fields.length} fields completed</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {/* Progress bar */}
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-green-500 h-2 rounded-full transition-all" style={{ width: `${fields.length > 0 ? (filledCount / fields.length) * 100 : 0}%` }} />
              </div>

              {/* Signature method */}
              <div>
                <p className="text-xs font-medium text-gray-300 mb-2">Create your signature:</p>
                <div className="flex gap-2 mb-2">
                  {(['draw', 'type'] as const).map(m => (
                    <button key={m} onClick={() => { setSigMethod(m); setSignatureData(''); }}
                      className={`flex-1 py-1.5 text-xs rounded border-2 capitalize font-medium ${
                        sigMethod === m ? 'border-[#9945FF] bg-[#9945FF]/10 text-[#9945FF]' : 'border-white/10 text-gray-400'
                      }`}>{m}</button>
                  ))}
                </div>
                <div className="min-h-[120px]">
                  {sigMethod === 'draw' && <SignatureCanvas onSignatureChange={handleSigChange} />}
                  {sigMethod === 'type' && <TypedSignature onSignatureChange={handleSigChange} initialName={signerName} />}
                </div>
                {signatureData && (
                  <p className="text-xs text-green-600 flex items-center gap-1 mt-1"><CheckCircle className="w-3 h-3" /> Signature ready</p>
                )}
              </div>

              {/* Field list */}
              <div className="border-t pt-3">
                <p className="text-xs font-medium text-gray-300 mb-2">Fields to complete:</p>
                <div className="space-y-1 max-h-48 overflow-auto">
                  {fields.map((f, i) => (
                    <button key={i} onClick={() => { setCurrentPage(f.pageNumber); setActiveFieldIdx(i); }}
                      className={`w-full flex items-center gap-2 text-xs p-2 rounded transition-all ${
                        activeFieldIdx === i ? 'bg-blue-500/10 border border-blue-500/30' : f.value ? 'bg-[#14F195]/10 text-[#14F195]' : 'bg-[#0f1225] hover:bg-gray-100'
                      }`}>
                      {f.value ? <CheckCircle className="w-3 h-3 text-green-500" /> : <Pen className="w-3 h-3 text-gray-400" />}
                      <span className="capitalize">{f.fieldType}</span>
                      <span className="text-gray-400 ml-auto">p.{f.pageNumber}</span>
                    </button>
                  ))}
                </div>
              </div>

              {error && <p className="text-xs text-red-500">{error}</p>}

              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={() => setStep('consent')}><ArrowLeft className="w-3 h-3 mr-1" /> Back</Button>
                <Button onClick={submitSigning} disabled={loading || !allFilled} size="sm" className="flex-1 bg-[#9945FF] hover:bg-[#7c35e0] text-white">
                  {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <>Submit Signature <CheckCircle className="w-3 h-3 ml-1" /></>}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* PDF Viewer */}
        <div className="flex-1 overflow-auto">
          {activeFieldIdx !== null && !fields[activeFieldIdx]?.value && (
            <div className="mb-3 p-2 bg-yellow-50 border border-yellow-200 rounded-lg flex items-center justify-between">
              <span className="text-sm text-yellow-800">Click &quot;Apply&quot; to fill the <strong className="capitalize">{fields[activeFieldIdx]?.fieldType}</strong> field</span>
              <Button size="sm" onClick={() => applyToField(activeFieldIdx)} className="bg-[#9945FF] hover:bg-[#7c35e0] text-white">Apply</Button>
            </div>
          )}
          <PdfViewer url={docUrl} currentPage={currentPage} onPageChange={setCurrentPage} onTotalPagesChange={setTotalPages}>
            {pageFields.map((field, idx) => {
              const globalIdx = fields.findIndex(f => f === field);
              return (
                <FieldOverlay
                  key={idx}
                  field={field}
                  isActive={activeFieldIdx === globalIdx}
                  onClick={() => {
                    if (!field.value) {
                      setActiveFieldIdx(globalIdx);
                      applyToField(globalIdx);
                    }
                  }}
                />
              );
            })}
          </PdfViewer>
        </div>
      </div>
    </div>
  );
}
