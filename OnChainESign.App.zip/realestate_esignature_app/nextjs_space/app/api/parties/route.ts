export const dynamic = 'force-dynamic';

import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

export async function POST(request: NextRequest) {
  try {
    const { documentId, parties } = await request.json();
    if (!documentId || !parties || !Array.isArray(parties) || parties.length === 0) {
      return NextResponse.json({ success: false, error: 'Missing document ID or parties' }, { status: 400 });
    }

    // Delete existing parties for this document and recreate
    await prisma.transactionParty.deleteMany({ where: { documentId } });

    const created = await prisma.transactionParty.createMany({
      data: parties.map((p: any, idx: number) => ({
        documentId,
        name: p.name || '',
        email: p.email || '',
        role: p.role || 'other',
        company: p.company || null,
        phone: p.phone || null,
        orderIndex: idx,
      })),
    });

    await prisma.auditLog.create({
      data: {
        documentId,
        action: 'PARTIES_DEFINED',
        actor: 'Administrator',
        details: `${parties.length} transaction parties defined: ${parties.map((p: any) => `${p.name} (${p.role})`).join(', ')}`,
      },
    });

    return NextResponse.json({ success: true, count: created.count });
  } catch (error: any) {
    console.error('Error saving parties:', error);
    return NextResponse.json({ success: false, error: error?.message || 'Failed to save parties' }, { status: 500 });
  }
}

export async function GET(request: NextRequest) {
  try {
    const documentId = request.nextUrl.searchParams.get('documentId');
    if (!documentId) {
      return NextResponse.json({ success: false, error: 'Missing documentId' }, { status: 400 });
    }

    const parties = await prisma.transactionParty.findMany({
      where: { documentId },
      orderBy: { orderIndex: 'asc' },
    });

    return NextResponse.json({ success: true, parties });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error?.message || 'Failed to fetch parties' }, { status: 500 });
  }
}
