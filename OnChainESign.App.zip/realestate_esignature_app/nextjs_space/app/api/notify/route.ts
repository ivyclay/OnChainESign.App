export const dynamic = "force-dynamic";

import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

export async function POST(request: Request) {
  try {
    const { signatureId, documentId } = await request.json();

    const document = await prisma.document.findUnique({
      where: { id: documentId },
      include: { signatures: true },
    });

    if (!document) {
      return NextResponse.json({ success: false, error: 'Document not found' }, { status: 404 });
    }

    const signature = document?.signatures?.find?.((s: { id?: string }) => s?.id === signatureId);
    if (!signature) {
      return NextResponse.json({ success: false, error: 'Signature not found' }, { status: 404 });
    }

    const appUrl = process.env.NEXTAUTH_URL ?? '';
    const appName = 'OnChainESign';
    const certificateUrl = `${appUrl}/certificate/${signatureId}`;
    const documentUrl = `${appUrl}/document/${documentId}`;

    const htmlBody = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="background: linear-gradient(135deg, #9945FF 0%, #2d5a8a 100%); padding: 30px; border-radius: 8px 8px 0 0;">
          <h1 style="color: white; margin: 0; font-size: 24px;">Document Signed Successfully</h1>
        </div>
        
        <div style="background: #f8f9fa; padding: 30px; border-radius: 0 0 8px 8px;">
          <p style="color: #333; font-size: 16px; margin-bottom: 20px;">
            Great news! A document has been electronically signed.
          </p>
          
          <div style="background: white; padding: 20px; border-radius: 8px; margin-bottom: 20px; border-left: 4px solid #14F195;">
            <h3 style="color: #9945FF; margin-top: 0;">Document Details</h3>
            <p style="margin: 8px 0;"><strong>Document:</strong> ${document?.fileName ?? 'N/A'}</p>
            <p style="margin: 8px 0;"><strong>Signed by:</strong> ${signature?.signerName ?? 'N/A'}</p>
            <p style="margin: 8px 0;"><strong>Email:</strong> ${signature?.signerEmail ?? 'N/A'}</p>
            <p style="margin: 8px 0;"><strong>Role:</strong> ${signature?.signerRole ?? 'N/A'}</p>
            <p style="margin: 8px 0;"><strong>Signed at:</strong> ${signature?.signedAt?.toLocaleString?.() ?? 'N/A'}</p>
          </div>
          
          <div style="text-align: center; margin: 30px 0;">
            <a href="${documentUrl}" style="display: inline-block; background: #9945FF; color: white; padding: 14px 28px; text-decoration: none; border-radius: 6px; font-weight: bold; margin: 5px;">View Document</a>
            <a href="${certificateUrl}" style="display: inline-block; background: #14F195; color: white; padding: 14px 28px; text-decoration: none; border-radius: 6px; font-weight: bold; margin: 5px;">View Certificate</a>
          </div>
          
          <div style="background: #e8f4e8; border-left: 4px solid #2e7d32; padding: 15px; margin-top: 20px;">
            <p style="margin: 0; color: #2e7d32; font-size: 14px;">
              <strong>✓ ESIGN Act & UETA Compliant · Blockchain Verified</strong><br>
              This signature meets all ESIGN Act and Uniform Electronic Transactions Act requirements.
            </p>
          </div>
        </div>
        
        <div style="text-align: center; padding: 20px; color: #666; font-size: 12px;">
          <p>This notification was sent by ${appName}</p>
        </div>
      </div>
    `;

    const response = await fetch('https://apps.abacus.ai/api/sendNotificationEmail', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        deployment_token: process.env.ABACUSAI_API_KEY,
        app_id: process.env.WEB_APP_ID,
        notification_id: process.env.NOTIF_ID_DOCUMENT_SIGNED_NOTIFICATION,
        subject: `Document Signed: ${document?.fileName ?? 'Document'}`,
        body: htmlBody,
        is_html: true,
        recipient_email: document?.agentEmail ?? '',
        sender_email: appUrl ? `noreply@${new URL(appUrl)?.hostname ?? 'app'}` : 'noreply@mail.abacusai.app',
        sender_alias: appName,
      }),
    });

    const result = await response?.json?.() ?? {};
    
    if (!result?.success) {
      if (result?.notification_disabled) {
        console.log('Notification disabled by user');
        return NextResponse.json({ success: true, message: 'Notification disabled' });
      }
      throw new Error(result?.message ?? 'Failed to send notification');
    }

    await prisma.auditLog.create({
      data: {
        documentId: documentId ?? '',
        signatureId: signatureId ?? '',
        action: 'NOTIFICATION_SENT',
        actor: 'System',
        details: `Email notification sent to ${document?.agentEmail ?? 'agent'}`,
      },
    });

    return NextResponse.json({ success: true, message: 'Notification sent' });
  } catch (error) {
    console.error('Error sending notification:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to send notification' },
      { status: 500 }
    );
  }
}
