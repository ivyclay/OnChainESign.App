export const dynamic = "force-dynamic";

import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { getFileUrl } from '@/lib/s3';

export async function GET(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const id = params?.id ?? '';

    const document = await prisma.document.findUnique({
      where: { id },
    });

    if (!document) {
      return NextResponse.json(
        { success: false, error: 'Document not found' },
        { status: 404 }
      );
    }

    const cloudPath = document?.cloudPath ?? '';
    const isPublic = cloudPath?.includes?.('/public/') ?? false;
    const url = await getFileUrl(cloudPath, isPublic);

    return NextResponse.json({ success: true, url });
  } catch (error) {
    console.error('Error getting document URL:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to get document URL' },
      { status: 500 }
    );
  }
}
