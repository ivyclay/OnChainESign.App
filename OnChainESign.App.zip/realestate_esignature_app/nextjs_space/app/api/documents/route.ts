export const dynamic = "force-dynamic";

import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { generateDocumentHash } from '@/lib/hash';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';

export async function POST(request: Request) {
  try {
    const data = await request.json();
    const {
      fileName,
      fileType,
      fileSize,
      cloudPath,
      agentName,
      agentEmail,
      documentContent,
    } = data;

    if (!fileName || !cloudPath || !agentName || !agentEmail) {
      return NextResponse.json(
        { success: false, error: 'Missing required fields' },
        { status: 400 }
      );
    }

    const documentHash = generateDocumentHash(documentContent ?? cloudPath);

    // Try to get authenticated user and enforce plan limits
    let userId: string | null = null;
    try {
      const session = await getServerSession(authOptions);
      if (session?.user?.id) {
        userId = session.user.id;

        const user = await prisma.user.findUnique({ where: { id: userId } });
        if (user && user.plan === 'free') {
          // Free plan: 3 documents per calendar month
          const startOfMonth = new Date();
          startOfMonth.setDate(1);
          startOfMonth.setHours(0, 0, 0, 0);
          const docsThisMonth = await prisma.document.count({
            where: { userId, createdAt: { gte: startOfMonth } },
          });
          if (docsThisMonth >= 3) {
            return NextResponse.json(
              { success: false, error: 'Free plan limit reached (3 documents/month). Upgrade to Pro for unlimited documents.' },
              { status: 403 }
            );
          }
        }
      }
    } catch {}

    const document = await prisma.document.create({
      data: {
        fileName: fileName ?? '',
        fileType: fileType ?? 'application/pdf',
        fileSize: fileSize ?? 0,
        cloudPath: cloudPath ?? '',
        documentHash: documentHash ?? '',
        agentName: agentName ?? '',
        agentEmail: agentEmail ?? '',
        status: 'pending',
        ...(userId ? { userId } : {}),
      },
    });

    await prisma.auditLog.create({
      data: {
        documentId: document?.id ?? '',
        action: 'DOCUMENT_UPLOADED',
        actor: agentName ?? 'Unknown',
        actorEmail: agentEmail ?? '',
        details: `Document "${fileName}" uploaded for signing`,
      },
    });

    return NextResponse.json({
      success: true,
      document: {
        id: document?.id ?? '',
        fileName: document?.fileName ?? '',
        status: document?.status ?? 'pending',
      },
    });
  } catch (error) {
    console.error('Error creating document:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to create document' },
      { status: 500 }
    );
  }
}

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request?.url ?? '');
    const id = searchParams?.get('id') ?? '';

    if (id) {
      const document = await prisma.document.findUnique({
        where: { id },
        include: {
          signatures: true,
          auditLogs: { orderBy: { timestamp: 'desc' } },
          parties: { orderBy: { orderIndex: 'asc' } },
        },
      });

      if (!document) {
        return NextResponse.json(
          { success: false, error: 'Document not found' },
          { status: 404 }
        );
      }

      return NextResponse.json({ success: true, document });
    }

    const documents = await prisma.document.findMany({
      orderBy: { createdAt: 'desc' },
      include: { signatures: true },
    });

    return NextResponse.json({ success: true, documents });
  } catch (error) {
    console.error('Error fetching documents:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to fetch documents' },
      { status: 500 }
    );
  }
}
