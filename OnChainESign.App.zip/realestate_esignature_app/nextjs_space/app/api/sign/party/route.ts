import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { getFileUrl } from '@/lib/s3';

export const dynamic = 'force-dynamic';

// Get document info for a specific party via their signing token
export async function GET(request: NextRequest) {
  try {
    const token = request.nextUrl.searchParams.get('token');
    if (!token) {
      return NextResponse.json({ success: false, error: 'Missing token' }, { status: 400 });
    }

    const party = await prisma.transactionParty.findUnique({
      where: { signingToken: token },
      include: {
        document: {
          include: {
            fields: true,
            parties: { orderBy: { orderIndex: 'asc' } },
            signatures: true,
          },
        },
      },
    });

    if (!party) {
      return NextResponse.json({ success: false, error: 'Invalid signing link' }, { status: 404 });
    }

    // Mark as viewed
    if (party.status === 'pending' || party.status === 'sent') {
      await prisma.transactionParty.update({
        where: { id: party.id },
        data: { status: 'viewed' },
      });
    }

    // Get document URL
    const url = await getFileUrl(party.document.cloudPath, false);

    // Filter fields for this party (assigned to them or unassigned)
    const myFields = party.document.fields.filter(
      f => !f.assignedPartyId || f.assignedPartyId === party.id
    );

    return NextResponse.json({
      success: true,
      party: {
        id: party.id,
        name: party.name,
        email: party.email,
        role: party.role,
        status: party.status,
        signedAt: party.signedAt,
      },
      document: {
        id: party.document.id,
        fileName: party.document.fileName,
        status: party.document.status,
        agentName: party.document.agentName,
      },
      fields: myFields,
      documentUrl: url,
      allParties: party.document.parties.map(p => ({
        id: p.id,
        name: p.name,
        role: p.role,
        status: p.status,
        signedAt: p.signedAt,
      })),
    });
  } catch (error: any) {
    console.error('Party sign error:', error);
    return NextResponse.json({ success: false, error: error?.message || 'Failed' }, { status: 500 });
  }
}

// Complete signing for a party
export async function POST(request: NextRequest) {
  try {
    const { token, fieldValues, signatureType, signatureData, consentGiven, intentConfirmed } = await request.json();
    if (!token || !fieldValues) {
      return NextResponse.json({ success: false, error: 'Missing data' }, { status: 400 });
    }

    const party = await prisma.transactionParty.findUnique({
      where: { signingToken: token },
      include: { document: { include: { parties: true } } },
    });

    if (!party) {
      return NextResponse.json({ success: false, error: 'Invalid signing link' }, { status: 404 });
    }

    if (party.signedAt) {
      return NextResponse.json({ success: false, error: 'You have already signed this document' }, { status: 400 });
    }

    const forwarded = request.headers.get('x-forwarded-for');
    const ipAddress = forwarded?.split(',')[0]?.trim() || 'unknown';
    const userAgent = request.headers.get('user-agent') || 'unknown';

    // Update field values
    for (const fv of fieldValues) {
      if (fv.id && fv.value) {
        await prisma.documentField.update({
          where: { id: fv.id },
          data: { value: fv.value, signedAt: new Date() },
        });
      }
    }

    // Import hash function
    const { generateSignatureHash } = await import('@/lib/hash');
    const signatureHash = generateSignatureHash(signatureData || party.name, party.email, new Date().toISOString());

    // Create signature record
    const signature = await prisma.signature.create({
      data: {
        documentId: party.document.id,
        signerName: party.name,
        signerEmail: party.email,
        signerRole: party.role,
        signatureType: signatureType || 'type',
        signatureData: signatureData || party.name,
        ipAddress,
        userAgent,
        deviceInfo: JSON.stringify({ ip: ipAddress }),
        timezone: 'UTC',
        consentGiven: consentGiven ?? true,
        intentConfirmed: intentConfirmed ?? true,
        signatureHash,
        partyId: party.id,
      },
    });

    // Mark party as signed
    await prisma.transactionParty.update({
      where: { id: party.id },
      data: { status: 'signed', signedAt: new Date() },
    });

    // Check if all parties have signed
    const allParties = party.document.parties;
    const otherUnsigned = allParties.filter(p => p.id !== party.id && !p.signedAt);
    const newDocStatus = otherUnsigned.length === 0 ? 'signed' : 'partially_signed';

    await prisma.document.update({
      where: { id: party.document.id },
      data: { status: newDocStatus },
    });

    // Audit log
    await prisma.auditLog.create({
      data: {
        documentId: party.document.id,
        signatureId: signature.id,
        action: 'PARTY_SIGNED',
        actor: party.name,
        actorEmail: party.email,
        ipAddress,
        userAgent,
        details: `${party.name} (${party.role}) signed the document. ${otherUnsigned.length} parties remaining.`,
      },
    });

    // Send notification to document creator
    try {
      await fetch(`${process.env.NEXTAUTH_URL || 'http://localhost:3000'}/api/notify`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ signatureId: signature.id, documentId: party.document.id }),
      });
    } catch {}

    return NextResponse.json({
      success: true,
      signature: { id: signature.id, signedAt: signature.signedAt, signatureHash },
      documentStatus: newDocStatus,
      remainingParties: otherUnsigned.length,
    });
  } catch (error: any) {
    console.error('Party sign POST error:', error);
    return NextResponse.json({ success: false, error: error?.message || 'Failed' }, { status: 500 });
  }
}
