import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { mintDocumentHash, getSolanaExplorerUrl, getWalletBalance } from '@/lib/solana';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';

export const dynamic = 'force-dynamic';

const LOW_BALANCE_THRESHOLD_SOL = 0.05; // Alert when below 0.05 SOL
const ADMIN_ALERT_EMAIL = 'ohrealty@yahoo.com';
const FREE_TIER_MINT_LIMIT = 3; // Free users: max 3 blockchain mints per month

async function checkAndAlertLowBalance() {
  try {
    const balance = await getWalletBalance();
    if (balance < LOW_BALANCE_THRESHOLD_SOL) {
      const notifId = process.env.NOTIF_ID_WALLET_LOW_BALANCE_ALERT;
      const appId = process.env.WEB_APP_ID;
      if (notifId && appId) {
        await fetch('https://apps.abacus.ai/api/sendNotificationEmail', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            app_id: appId,
            notification_id: notifId,
            recipient_email: ADMIN_ALERT_EMAIL,
            subject: `⚠️ OnChainESign Wallet Low Balance: ${balance.toFixed(4)} SOL`,
            body: `
              <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                <h2 style="color: #9945FF;">⚠️ Wallet Balance Alert</h2>
                <p>Your OnChainESign Solana wallet balance is <strong>${balance.toFixed(4)} SOL</strong>, which is below the ${LOW_BALANCE_THRESHOLD_SOL} SOL threshold.</p>
                <p>Each blockchain transaction costs ~0.000005 SOL, but the wallet needs a minimum balance to process transactions.</p>
                <p><strong>Wallet Address:</strong> Ac5yAeYH9W9v8vnT5MB3b8apsiSQUd2BPUSryosw3R3b</p>
                <p>Please fund the wallet soon to ensure uninterrupted document minting.</p>
                <hr style="border: none; border-top: 1px solid #eee; margin: 20px 0;" />
                <p style="color: #888; font-size: 12px;">OnChainESign · Blockchain-Verified E-Signatures</p>
              </div>
            `,
          }),
        });
        console.log(`Low balance alert sent: ${balance.toFixed(4)} SOL`);
      }
    }
  } catch (err) {
    console.error('Failed to check/alert wallet balance:', err);
  }
}

export async function POST(request: NextRequest) {
  try {
    const { documentId } = await request.json();
    if (!documentId) {
      return NextResponse.json({ success: false, error: 'Missing documentId' }, { status: 400 });
    }

    const doc = await prisma.document.findUnique({ where: { id: documentId } });
    if (!doc) {
      return NextResponse.json({ success: false, error: 'Document not found' }, { status: 404 });
    }

    if (doc.blockchainTxHash) {
      return NextResponse.json({
        success: true,
        alreadyMinted: true,
        txHash: doc.blockchainTxHash,
        network: doc.blockchainNetwork,
        explorerUrl: getSolanaExplorerUrl(doc.blockchainTxHash, doc.blockchainNetwork || undefined),
      });
    }

    // Enforce free-tier minting limits
    try {
      const session = await getServerSession(authOptions);
      if (session?.user?.id) {
        const user = await prisma.user.findUnique({ where: { id: session.user.id } });
        if (user && user.plan === 'free') {
          const startOfMonth = new Date();
          startOfMonth.setDate(1);
          startOfMonth.setHours(0, 0, 0, 0);
          const mintsThisMonth = await prisma.document.count({
            where: {
              userId: user.id,
              blockchainTxHash: { not: null },
              createdAt: { gte: startOfMonth },
            },
          });
          if (mintsThisMonth >= FREE_TIER_MINT_LIMIT) {
            return NextResponse.json({
              success: false,
              error: `Free plan limit reached (${FREE_TIER_MINT_LIMIT} blockchain mints/month). Upgrade to Pro for unlimited minting.`,
            }, { status: 403 });
          }
        }
      }
    } catch {}

    // Check balance before minting — block if too low
    const balanceBefore = await getWalletBalance();
    if (balanceBefore < 0.001) {
      return NextResponse.json({
        success: false,
        error: 'Wallet balance too low to process blockchain transaction. Please contact support.',
      }, { status: 503 });
    }

    const { txHash, network } = await mintDocumentHash(doc.documentHash, doc.id);

    await prisma.document.update({
      where: { id: documentId },
      data: { blockchainTxHash: txHash, blockchainNetwork: network, status: 'completed' },
    });

    await prisma.auditLog.create({
      data: {
        documentId,
        action: 'BLOCKCHAIN_MINTED',
        actor: 'System',
        details: `Document hash minted to Solana ${network}. TX: ${txHash}`,
      },
    });

    // Check balance after minting and alert if low (non-blocking)
    checkAndAlertLowBalance();

    return NextResponse.json({
      success: true,
      txHash,
      network,
      explorerUrl: getSolanaExplorerUrl(txHash, network),
    });
  } catch (error: any) {
    console.error('Blockchain mint error:', error);
    return NextResponse.json({ success: false, error: error?.message || 'Blockchain minting failed' }, { status: 500 });
  }
}
