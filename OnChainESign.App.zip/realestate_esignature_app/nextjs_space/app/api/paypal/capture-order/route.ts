import { NextRequest, NextResponse } from 'next/server';
import { captureOrder } from '@/lib/paypal';
import { prisma } from '@/lib/db';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';

export const dynamic = 'force-dynamic';

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ success: false, error: 'Authentication required' }, { status: 401 });
    }

    const { orderId, planType } = await request.json();
    if (!orderId) {
      return NextResponse.json({ success: false, error: 'Missing orderId' }, { status: 400 });
    }

    const capture = await captureOrder(orderId);

    if (capture.status === 'COMPLETED') {
      const captureUnit = capture.purchase_units?.[0]?.payments?.captures?.[0];
      const amount = captureUnit?.amount?.value || '0';

      // Update user plan based on purchase
      if (planType === 'pro_monthly' || planType === 'pro_annual') {
        await prisma.user.update({
          where: { id: session.user.id },
          data: { plan: 'pro', documentsUsed: 0 },
        });
      } else if (planType === 'per_document') {
        // Add 1 document credit
        await prisma.user.update({
          where: { id: session.user.id },
          data: { documentsUsed: { decrement: 1 } },
        });
      }

      // Record subscription/payment
      await prisma.subscription.create({
        data: {
          userId: session.user.id,
          plan: planType === 'per_document' ? 'per_document' : 'pro',
          status: 'active',
          paypalOrderId: orderId,
          amount: parseFloat(amount),
          currency: 'USD',
          currentPeriodStart: new Date(),
          currentPeriodEnd: planType === 'pro_annual'
            ? new Date(Date.now() + 365 * 24 * 60 * 60 * 1000)
            : new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
        },
      });

      return NextResponse.json({
        success: true,
        status: 'COMPLETED',
        amount,
        planType,
      });
    } else {
      return NextResponse.json({
        success: false,
        error: `Payment not completed. Status: ${capture.status}`,
      }, { status: 400 });
    }
  } catch (error: any) {
    console.error('PayPal capture error:', error);
    return NextResponse.json({ success: false, error: error?.message || 'Failed to capture payment' }, { status: 500 });
  }
}
