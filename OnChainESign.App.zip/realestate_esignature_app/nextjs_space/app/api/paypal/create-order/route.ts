import { NextRequest, NextResponse } from 'next/server';
import { createOrder } from '@/lib/paypal';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';

export const dynamic = 'force-dynamic';

const PLANS: Record<string, { amount: string; description: string }> = {
  pro_monthly: { amount: '29.00', description: 'OnChainESign Pro - Monthly' },
  pro_annual: { amount: '290.00', description: 'OnChainESign Pro - Annual' },
  per_document: { amount: '4.99', description: 'OnChainESign - Single Document' },
};

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ success: false, error: 'Authentication required' }, { status: 401 });
    }

    const { planType } = await request.json();
    const plan = PLANS[planType];
    if (!plan) {
      return NextResponse.json({ success: false, error: 'Invalid plan type' }, { status: 400 });
    }

    const order = await createOrder(plan.amount, plan.description, session.user.id);

    return NextResponse.json({
      success: true,
      orderId: order.id,
      status: order.status,
    });
  } catch (error: any) {
    console.error('PayPal create order error:', error);
    return NextResponse.json({ success: false, error: error?.message || 'Failed to create order' }, { status: 500 });
  }
}
