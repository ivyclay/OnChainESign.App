import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import crypto from 'crypto';

export const dynamic = 'force-dynamic';

// Generate signing tokens for all parties and optionally send invites
export async function POST(request: NextRequest) {
  try {
    const { documentId, sendEmails } = await request.json();
    if (!documentId) {
      return NextResponse.json({ success: false, error: 'Missing documentId' }, { status: 400 });
    }

    const doc = await prisma.document.findUnique({
      where: { id: documentId },
      include: { parties: { orderBy: { orderIndex: 'asc' } } },
    });
    if (!doc) {
      return NextResponse.json({ success: false, error: 'Document not found' }, { status: 404 });
    }

    // Generate unique signing tokens for each party that doesn't have one
    const updatedParties = [];
    for (const party of doc.parties) {
      let token = party.signingToken;
      if (!token) {
        token = crypto.randomBytes(32).toString('hex');
        await prisma.transactionParty.update({
          where: { id: party.id },
          data: { signingToken: token },
        });
      }
      updatedParties.push({ ...party, signingToken: token });
    }

    // Send email invitations if requested
    if (sendEmails) {
      const baseUrl = process.env.NEXTAUTH_URL || 'http://localhost:3000';
      const notifId = process.env.NOTIF_ID_DOCUMENT_SIGNED_NOTIFICATION;
      const apiKey = process.env.ABACUSAI_API_KEY;

      for (const party of updatedParties) {
        if (!party.email) continue;
        const signingUrl = `${baseUrl}/sign/party/${party.signingToken}`;
        try {
          await fetch('https://apps.abacus.ai/api/sendNotificationEmail', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              notification_id: notifId,
              api_key: apiKey,
              recipient_email: party.email,
              recipient_name: party.name,
              subject: `Action Required: Sign "${doc.fileName}" on OnChainESign`,
              html_body: `
                <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
                  <div style="background: #9945FF; color: white; padding: 20px; border-radius: 8px 8px 0 0; text-align: center;">
                    <h1 style="margin: 0; font-size: 22px;">OnChainESign</h1>
                    <p style="margin: 5px 0 0; font-size: 12px; color: #14F195;">Blockchain-Verified · Legally Binding</p>
                  </div>
                  <div style="background: white; padding: 30px; border: 1px solid #e5e7eb; border-top: none; border-radius: 0 0 8px 8px;">
                    <h2 style="color: #9945FF; margin-top: 0;">You&apos;ve been invited to sign a document</h2>
                    <p style="color: #555;">Hi ${party.name},</p>
                    <p style="color: #555;">${doc.agentName} has requested your signature on <strong>${doc.fileName}</strong> as <strong>${party.role}</strong>.</p>
                    <div style="text-align: center; margin: 30px 0;">
                      <a href="${signingUrl}" style="background: #14F195; color: white; padding: 14px 28px; border-radius: 8px; text-decoration: none; font-weight: bold; display: inline-block;">Review & Sign Document</a>
                    </div>
                    <p style="color: #888; font-size: 12px;">This link is unique to you. Do not share it. Your signature will be blockchain-verified on Solana.</p>
                    <hr style="border: none; border-top: 1px solid #e5e7eb; margin: 20px 0;" />
                    <p style="color: #aaa; font-size: 11px; text-align: center;">ESIGN Act & UETA Compliant · Blockchain Verified</p>
                  </div>
                </div>
              `,
            }),
          });

          // Update party status to sent
          await prisma.transactionParty.update({
            where: { id: party.id },
            data: { status: 'sent' },
          });
        } catch (err) {
          console.error(`Failed to send invite to ${party.email}:`, err);
        }
      }

      await prisma.auditLog.create({
        data: {
          documentId,
          action: 'INVITATIONS_SENT',
          actor: doc.agentName,
          actorEmail: doc.agentEmail,
          details: `Signing invitations sent to ${updatedParties.length} parties`,
        },
      });
    }

    return NextResponse.json({
      success: true,
      parties: updatedParties.map(p => ({
        id: p.id,
        name: p.name,
        email: p.email,
        role: p.role,
        status: p.status,
        signingToken: p.signingToken,
      })),
    });
  } catch (error: any) {
    console.error('Invite error:', error);
    return NextResponse.json({ success: false, error: error?.message || 'Failed' }, { status: 500 });
  }
}
