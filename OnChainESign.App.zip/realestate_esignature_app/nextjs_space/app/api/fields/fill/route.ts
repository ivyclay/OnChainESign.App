import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { generateSignatureHash } from '@/lib/hash';

export const dynamic = 'force-dynamic';

export async function POST(request: NextRequest) {
  try {
    const { documentId, fieldValues, signerName, signerEmail, signerRole, signatureType, signatureData, consentGiven, intentConfirmed } = await request.json();

    if (!documentId || !fieldValues || !signerName || !signerEmail) {
      return NextResponse.json({ success: false, error: 'Missing required data' }, { status: 400 });
    }

    const forwarded = request.headers.get('x-forwarded-for');
    const ipAddress = forwarded?.split(',')[0]?.trim() || 'unknown';
    const userAgent = request.headers.get('user-agent') || 'unknown';

    // Update each field with its value
    for (const fv of fieldValues) {
      if (fv.id && fv.value) {
        await prisma.documentField.update({
          where: { id: fv.id },
          data: { value: fv.value, signedAt: new Date() },
        });
      }
    }

    // Create signature record
    const signatureHash = generateSignatureHash(signatureData || signerName, signerEmail, new Date().toISOString());
    const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC';

    const signature = await prisma.signature.create({
      data: {
        documentId,
        signerName,
        signerEmail,
        signerRole: signerRole || 'client',
        signatureType: signatureType || 'type',
        signatureData: signatureData || signerName,
        ipAddress,
        userAgent,
        deviceInfo: JSON.stringify({ ip: ipAddress }),
        timezone,
        consentGiven: consentGiven ?? true,
        intentConfirmed: intentConfirmed ?? true,
        signatureHash,
      },
    });

    // Update document status
    await prisma.document.update({
      where: { id: documentId },
      data: { status: 'signed' },
    });

    // Audit log
    await prisma.auditLog.create({
      data: {
        documentId,
        signatureId: signature.id,
        action: 'DOCUMENT_SIGNED',
        actor: signerName,
        actorEmail: signerEmail,
        ipAddress,
        userAgent,
        details: `Document signed by ${signerName} (${signerEmail}). Hash: ${signatureHash}`,
      },
    });

    return NextResponse.json({ success: true, signature: { id: signature.id, signedAt: signature.signedAt, signatureHash } });
  } catch (error: any) {
    console.error('Fill error:', error);
    return NextResponse.json({ success: false, error: error?.message || 'Failed' }, { status: 500 });
  }
}
