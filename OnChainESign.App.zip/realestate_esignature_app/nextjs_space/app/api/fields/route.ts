import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

// Save fields for a document
export async function POST(request: NextRequest) {
  try {
    const { documentId, fields } = await request.json();
    if (!documentId || !fields || !Array.isArray(fields)) {
      return NextResponse.json({ success: false, error: 'Missing data' }, { status: 400 });
    }

    // Delete existing fields and recreate
    await prisma.documentField.deleteMany({ where: { documentId } });

    const created = await prisma.documentField.createMany({
      data: fields.map((f: any) => ({
        documentId,
        fieldType: f.fieldType,
        pageNumber: f.pageNumber,
        xPercent: f.xPercent,
        yPercent: f.yPercent,
        widthPercent: f.widthPercent,
        heightPercent: f.heightPercent,
        label: f.label || null,
        required: f.required !== false,
        assignedPartyId: f.assignedPartyId || null,
      })),
    });

    // Update document status to pending (ready for signing)
    await prisma.document.update({
      where: { id: documentId },
      data: { status: 'pending' },
    });

    await prisma.auditLog.create({
      data: {
        documentId,
        action: 'FIELDS_PLACED',
        actor: 'Administrator',
        details: `${fields.length} fields placed on document`,
      },
    });

    return NextResponse.json({ success: true, count: created.count });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error?.message || 'Failed to save fields' }, { status: 500 });
  }
}

// Get fields for a document
export async function GET(request: NextRequest) {
  try {
    const documentId = request.nextUrl.searchParams.get('documentId');
    if (!documentId) {
      return NextResponse.json({ success: false, error: 'Missing documentId' }, { status: 400 });
    }

    const fields = await prisma.documentField.findMany({
      where: { documentId },
      orderBy: [{ pageNumber: 'asc' }, { createdAt: 'asc' }],
    });

    return NextResponse.json({ success: true, fields });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error?.message || 'Failed' }, { status: 500 });
  }
}
