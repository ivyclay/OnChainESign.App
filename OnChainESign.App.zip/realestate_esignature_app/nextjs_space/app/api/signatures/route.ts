export const dynamic = "force-dynamic";

import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { generateSignatureHash } from '@/lib/hash';

export async function POST(request: Request) {
  try {
    const data = await request.json();
    const {
      documentId,
      signerName,
      signerEmail,
      signerRole,
      signatureType,
      signatureData,
      ipAddress,
      userAgent,
      deviceInfo,
      timezone,
      consentGiven,
      intentConfirmed,
    } = data ?? {};

    if (!documentId || !signerName || !signerEmail || !signatureData) {
      return NextResponse.json(
        { success: false, error: 'Missing required fields' },
        { status: 400 }
      );
    }

    const document = await prisma.document.findUnique({
      where: { id: documentId },
    });

    if (!document) {
      return NextResponse.json(
        { success: false, error: 'Document not found' },
        { status: 404 }
      );
    }

    const signedAt = new Date();
    const signatureHash = generateSignatureHash(
      signatureData ?? '',
      signerEmail ?? '',
      signedAt?.toISOString?.() ?? ''
    );

    const signature = await prisma.signature.create({
      data: {
        documentId: documentId ?? '',
        signerName: signerName ?? '',
        signerEmail: signerEmail ?? '',
        signerRole: signerRole ?? 'client',
        signatureType: signatureType ?? 'draw',
        signatureData: signatureData ?? '',
        signedAt,
        ipAddress: ipAddress ?? 'Unknown',
        userAgent: userAgent ?? 'Unknown',
        deviceInfo: deviceInfo ?? '{}',
        timezone: timezone ?? 'Unknown',
        consentGiven: consentGiven ?? true,
        intentConfirmed: intentConfirmed ?? true,
        signatureHash: signatureHash ?? '',
      },
    });

    await prisma.document.update({
      where: { id: documentId },
      data: { status: 'signed' },
    });

    await prisma.auditLog.create({
      data: {
        documentId: documentId ?? '',
        signatureId: signature?.id ?? '',
        action: 'DOCUMENT_SIGNED',
        actor: signerName ?? 'Unknown',
        actorEmail: signerEmail ?? '',
        ipAddress: ipAddress ?? '',
        userAgent: userAgent ?? '',
        details: JSON.stringify({
          signatureType,
          signatureHash,
          timezone,
          consentGiven,
          intentConfirmed,
          role: signerRole,
        }),
      },
    });

    return NextResponse.json({
      success: true,
      signature: {
        id: signature?.id ?? '',
        signedAt: signature?.signedAt ?? '',
        signatureHash: signature?.signatureHash ?? '',
      },
    });
  } catch (error) {
    console.error('Error creating signature:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to create signature' },
      { status: 500 }
    );
  }
}
