export const dynamic = "force-dynamic";

import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

function generateCertificateHTML(
  document: { id: string; fileName: string; documentHash: string; agentName: string; agentEmail: string },
  signature: {
    id: string;
    signerName: string;
    signerEmail: string;
    signerRole: string;
    signatureType: string;
    signedAt: Date;
    ipAddress: string;
    timezone: string;
    signatureHash: string;
    consentGiven: boolean;
    intentConfirmed: boolean;
  },
  auditLogs: Array<{ action: string; actor: string; timestamp: Date; details?: string | null }>
): string {
  const formatDate = (date: Date) => {
    return date?.toLocaleString?.('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      timeZoneName: 'short',
    }) ?? '';
  };

  return `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="UTF-8">
      <title>Certificate of Completion</title>
      <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Georgia', serif; background: #0B0E17; padding: 40px; }
        .certificate { max-width: 800px; margin: 0 auto; background: #12152B; border: 2px solid #1f2240; padding: 50px; position: relative; border-radius: 12px; }
        .border-inner { border: 1px solid rgba(153,69,255,0.2); padding: 40px; border-radius: 8px; }
        .header { text-align: center; margin-bottom: 30px; }
        .header h1 { background: linear-gradient(135deg, #9945FF, #14F195); -webkit-background-clip: text; -webkit-text-fill-color: transparent; font-size: 32px; margin-bottom: 10px; text-transform: uppercase; letter-spacing: 4px; }
        .header .subtitle { color: #8b8fa3; font-style: italic; font-size: 14px; }
        .gold-line { height: 2px; background: linear-gradient(90deg, transparent, #9945FF, #14F195, transparent); margin: 20px 0; }
        .content { margin: 30px 0; }
        .section { margin-bottom: 25px; }
        .section-title { background: linear-gradient(135deg, #9945FF, #14F195); -webkit-background-clip: text; -webkit-text-fill-color: transparent; font-size: 16px; font-weight: bold; margin-bottom: 10px; text-transform: uppercase; letter-spacing: 1px; }
        .info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; }
        .info-item { }
        .info-label { color: #8b8fa3; font-size: 11px; text-transform: uppercase; letter-spacing: 0.5px; }
        .info-value { color: #e2e4ed; font-size: 14px; margin-top: 2px; word-break: break-all; }
        .audit-log { background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.05); padding: 15px; border-radius: 8px; margin-top: 15px; }
        .audit-entry { font-size: 12px; color: #a0a3b5; padding: 8px 0; border-bottom: 1px solid rgba(255,255,255,0.05); }
        .audit-entry:last-child { border-bottom: none; }
        .compliance-notice { background: rgba(20,241,149,0.05); border-left: 4px solid #14F195; padding: 15px; margin-top: 20px; border-radius: 0 8px 8px 0; }
        .compliance-notice h3 { color: #14F195; font-size: 14px; margin-bottom: 8px; }
        .compliance-notice p { font-size: 12px; color: #c0c3d0; line-height: 1.6; }
        .compliance-intl { background: rgba(153,69,255,0.05); border-left: 4px solid #9945FF; padding: 15px; margin-top: 12px; border-radius: 0 8px 8px 0; }
        .compliance-intl h3 { color: #9945FF; font-size: 14px; margin-bottom: 8px; }
        .compliance-intl p { font-size: 12px; color: #c0c3d0; line-height: 1.6; }
        .footer { text-align: center; margin-top: 40px; padding-top: 20px; border-top: 1px solid rgba(255,255,255,0.05); }
        .footer p { font-size: 11px; color: #8b8fa3; }
        .seal { position: absolute; bottom: 80px; right: 80px; width: 100px; height: 100px; border: 2px solid #9945FF; border-radius: 50%; display: flex; align-items: center; justify-content: center; text-align: center; font-size: 10px; color: #9945FF; font-weight: bold; text-transform: uppercase; }
        .hash-value { font-family: monospace; font-size: 10px; word-break: break-all; background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.05); padding: 8px; border-radius: 4px; color: #14F195; }
      </style>
    </head>
    <body>
      <div class="certificate">
        <div class="border-inner">
          <div class="header">
            <h1>Certificate of Completion</h1>
            <p class="subtitle">Electronic Signature Verification Document &mdash; OnChainESign</p>
          </div>
          
          <div class="gold-line"></div>
          
          <div class="content">
            <div class="section">
              <div class="section-title">Document Information</div>
              <div class="info-grid">
                <div class="info-item">
                  <div class="info-label">Document Name</div>
                  <div class="info-value">${document?.fileName ?? 'N/A'}</div>
                </div>
                <div class="info-item">
                  <div class="info-label">Document ID</div>
                  <div class="info-value">${document?.id ?? 'N/A'}</div>
                </div>
                <div class="info-item">
                  <div class="info-label">Requesting Agent</div>
                  <div class="info-value">${document?.agentName ?? 'N/A'}</div>
                </div>
                <div class="info-item">
                  <div class="info-label">Agent Email</div>
                  <div class="info-value">${document?.agentEmail ?? 'N/A'}</div>
                </div>
              </div>
              <div style="margin-top: 15px;">
                <div class="info-label">Document Hash (SHA-256)</div>
                <div class="hash-value">${document?.documentHash ?? 'N/A'}</div>
              </div>
            </div>

            <div class="section">
              <div class="section-title">Signature Information</div>
              <div class="info-grid">
                <div class="info-item">
                  <div class="info-label">Signer Name</div>
                  <div class="info-value">${signature?.signerName ?? 'N/A'}</div>
                </div>
                <div class="info-item">
                  <div class="info-label">Signer Email</div>
                  <div class="info-value">${signature?.signerEmail ?? 'N/A'}</div>
                </div>
                <div class="info-item">
                  <div class="info-label">Signer Role</div>
                  <div class="info-value" style="text-transform: capitalize;">${signature?.signerRole ?? 'N/A'}</div>
                </div>
                <div class="info-item">
                  <div class="info-label">Signature Method</div>
                  <div class="info-value" style="text-transform: capitalize;">${signature?.signatureType ?? 'N/A'}</div>
                </div>
                <div class="info-item">
                  <div class="info-label">Date & Time Signed</div>
                  <div class="info-value">${formatDate(signature?.signedAt)}</div>
                </div>
                <div class="info-item">
                  <div class="info-label">Timezone</div>
                  <div class="info-value">${signature?.timezone ?? 'N/A'}</div>
                </div>
                <div class="info-item">
                  <div class="info-label">IP Address</div>
                  <div class="info-value">${signature?.ipAddress ?? 'N/A'}</div>
                </div>
                <div class="info-item">
                  <div class="info-label">Signature ID</div>
                  <div class="info-value">${signature?.id ?? 'N/A'}</div>
                </div>
              </div>
              <div style="margin-top: 15px;">
                <div class="info-label">Signature Hash (SHA-256)</div>
                <div class="hash-value">${signature?.signatureHash ?? 'N/A'}</div>
              </div>
            </div>

            <div class="section">
              <div class="section-title">Consent & Intent Verification</div>
              <div class="info-grid">
                <div class="info-item">
                  <div class="info-label">Electronic Signing Consent</div>
                  <div class="info-value" style="color: ${signature?.consentGiven ? '#2e7d32' : '#c62828'};">
                    ${signature?.consentGiven ? '✓ Granted' : '✗ Not Granted'}
                  </div>
                </div>
                <div class="info-item">
                  <div class="info-label">Intent to Sign Confirmed</div>
                  <div class="info-value" style="color: ${signature?.intentConfirmed ? '#2e7d32' : '#c62828'};">
                    ${signature?.intentConfirmed ? '✓ Confirmed' : '✗ Not Confirmed'}
                  </div>
                </div>
              </div>
            </div>

            <div class="section">
              <div class="section-title">Audit Trail</div>
              <div class="audit-log">
                ${(auditLogs ?? [])?.map?.(log => `
                  <div class="audit-entry">
                    <strong>${log?.action ?? 'Unknown Action'}</strong> by ${log?.actor ?? 'Unknown'}
                    <br><span style="color: #888;">${formatDate(log?.timestamp ?? new Date())}</span>
                  </div>
                `)?.join?.('') ?? ''}
              </div>
            </div>

            <div class="compliance-notice">
              <h3>Electronic Signature Compliance Statement</h3>
              <p>
                This electronic signature and document are legally binding under the U.S. Electronic Signatures in Global and National Commerce Act 
                (ESIGN Act, 15 U.S.C. §7001 et seq.) and the Uniform Electronic Transactions Act (UETA) as adopted by all U.S. states. 
                The signer demonstrated clear intent to sign, provided explicit consent to conduct business electronically, 
                and this certificate provides a comprehensive audit trail linking the signature to this record. 
                The document hash is verifiable on-chain via Solana blockchain. Any modification to the signed document will invalidate the signature hash.
              </p>
              <p style="margin-top:8px;">
                <strong>Consumer Rights:</strong> In accordance with the ESIGN Act consumer consent provisions (15 U.S.C. §7001(c)), 
                signers may withdraw consent to electronic records at any time by contacting the document sender. 
                Withdrawal of consent does not affect the legal validity of signatures completed prior to withdrawal.
              </p>
            </div>

            <div class="compliance-notice" style="margin-top:12px;">
              <h3>International Compliance</h3>
              <p>
                This electronic signature is designed to comply with applicable electronic signature laws in major jurisdictions including:
                <strong>European Union</strong> — eIDAS Regulation (EU No. 910/2014) recognizing advanced electronic signatures;
                <strong>United Kingdom</strong> — Electronic Communications Act 2000 and UK eIDAS (retained EU law);
                <strong>Canada</strong> — Personal Information Protection and Electronic Documents Act (PIPEDA) and Uniform Electronic Commerce Act (UECA);
                <strong>Australia</strong> — Electronic Transactions Act 1999 (Cth).
                Parties should consult local counsel for jurisdiction-specific requirements.
              </p>
            </div>
          </div>

          <div class="seal">
            Electronically<br>Verified
          </div>

          <div class="footer">
            <p>This certificate was automatically generated upon completion of the electronic signature process.</p>
            <p>Certificate generated on ${formatDate(new Date())}</p>
          </div>
        </div>
      </div>
    </body>
    </html>
  `;
}

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request?.url ?? '');
    const signatureId = searchParams?.get?.('signatureId') ?? '';
    const format = searchParams?.get?.('format') ?? 'html';

    if (!signatureId) {
      return NextResponse.json(
        { success: false, error: 'Missing signatureId' },
        { status: 400 }
      );
    }

    const signature = await prisma.signature.findUnique({
      where: { id: signatureId },
      include: {
        document: {
          include: {
            auditLogs: { orderBy: { timestamp: 'asc' } },
          },
        },
      },
    });

    if (!signature) {
      return NextResponse.json(
        { success: false, error: 'Signature not found' },
        { status: 404 }
      );
    }

    const document = signature?.document;
    const auditLogs = document?.auditLogs ?? [];

    const html = generateCertificateHTML(
      {
        id: document?.id ?? '',
        fileName: document?.fileName ?? '',
        documentHash: document?.documentHash ?? '',
        agentName: document?.agentName ?? '',
        agentEmail: document?.agentEmail ?? '',
      },
      {
        id: signature?.id ?? '',
        signerName: signature?.signerName ?? '',
        signerEmail: signature?.signerEmail ?? '',
        signerRole: signature?.signerRole ?? '',
        signatureType: signature?.signatureType ?? '',
        signedAt: signature?.signedAt ?? new Date(),
        ipAddress: signature?.ipAddress ?? '',
        timezone: signature?.timezone ?? '',
        signatureHash: signature?.signatureHash ?? '',
        consentGiven: signature?.consentGiven ?? false,
        intentConfirmed: signature?.intentConfirmed ?? false,
      },
      auditLogs?.map?.((log: { action?: string; actor?: string; timestamp?: Date; details?: string | null }) => ({
        action: log?.action ?? '',
        actor: log?.actor ?? '',
        timestamp: log?.timestamp ?? new Date(),
        details: log?.details ?? null,
      })) ?? []
    );

    if (format === 'pdf') {
      const createResponse = await fetch('https://apps.abacus.ai/api/createConvertHtmlToPdfRequest', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          deployment_token: process.env.ABACUSAI_API_KEY,
          html_content: html,
          pdf_options: { format: 'A4', print_background: true },
          base_url: process.env.NEXTAUTH_URL ?? '',
        }),
      });

      if (!createResponse?.ok) {
        return NextResponse.json({ success: false, error: 'Failed to initiate PDF generation' }, { status: 500 });
      }

      const { request_id } = await createResponse?.json?.() ?? {};
      if (!request_id) {
        return NextResponse.json({ success: false, error: 'No request ID returned' }, { status: 500 });
      }

      const maxAttempts = 60;
      let attempts = 0;

      while (attempts < maxAttempts) {
        await new Promise(resolve => setTimeout(resolve, 1000));

        const statusResponse = await fetch('https://apps.abacus.ai/api/getConvertHtmlToPdfStatus', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ request_id, deployment_token: process.env.ABACUSAI_API_KEY }),
        });

        const statusResult = await statusResponse?.json?.() ?? {};
        const status = statusResult?.status ?? 'FAILED';
        const result = statusResult?.result ?? null;

        if (status === 'SUCCESS' && result?.result) {
          const pdfBuffer = Buffer.from(result?.result ?? '', 'base64');
          return new NextResponse(pdfBuffer, {
            headers: {
              'Content-Type': 'application/pdf',
              'Content-Disposition': `attachment; filename="certificate-${signatureId}.pdf"`,
            },
          });
        } else if (status === 'FAILED') {
          return NextResponse.json({ success: false, error: 'PDF generation failed' }, { status: 500 });
        }
        attempts++;
      }

      return NextResponse.json({ success: false, error: 'PDF generation timed out' }, { status: 500 });
    }

    return new NextResponse(html, {
      headers: { 'Content-Type': 'text/html' },
    });
  } catch (error) {
    console.error('Error generating certificate:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to generate certificate' },
      { status: 500 }
    );
  }
}
