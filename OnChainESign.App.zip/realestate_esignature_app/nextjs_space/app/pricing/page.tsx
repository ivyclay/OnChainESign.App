"use client";

import { useSession } from 'next-auth/react';
import { FileSignature, Check, Crown, Zap, Building2, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import Link from 'next/link';

const PLANS = [
  {
    name: 'Free',
    price: '$0',
    period: 'forever',
    desc: 'Perfect for getting started',
    icon: <Zap className="w-6 h-6" />,
    borderColor: 'border-white/10',
    features: [
      '3 signatures per month',
      'Up to 3 parties per document',
      'Blockchain verification',
      'Email notifications',
      'Audit trail & certificates',
    ],
    cta: 'Current Plan',
    planId: 'free',
    checkoutPlan: '',
  },
  {
    name: 'Pro',
    price: '$29',
    period: '/month',
    desc: 'For professionals & small teams',
    icon: <Crown className="w-6 h-6" />,
    borderColor: 'border-[#9945FF]/50',
    popular: true,
    features: [
      'Unlimited documents',
      'Unlimited parties per document',
      'Priority blockchain minting',
      'Bulk email invitations',
      'Advanced audit logs',
      'API access',
      'Custom branding (coming soon)',
    ],
    cta: 'Upgrade to Pro',
    planId: 'pro',
    checkoutPlan: 'pro_monthly',
  },
  {
    name: 'Enterprise',
    price: '$99',
    period: '/month',
    desc: 'For brokerages & title companies',
    icon: <Building2 className="w-6 h-6" />,
    borderColor: 'border-[#14F195]/30',
    features: [
      'Everything in Pro',
      'Team management',
      'White-label embedding',
      'Dedicated support',
      'Custom integrations',
      'SLA guarantees',
      'Multi-blockchain support',
    ],
    cta: 'Contact Sales',
    planId: 'enterprise',
    checkoutPlan: '',
  },
];

export default function PricingPage() {
  const { data: session } = useSession() || {};
  const userPlan = (session?.user as any)?.plan || 'free';

  return (
    <main className="min-h-screen bg-[#0B0E17] text-white">
      <header className="bg-[#0B0E17]/95 backdrop-blur-xl border-b border-white/5 text-white py-3 px-4 sticky top-0 z-50">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <FileSignature className="w-6 h-6 text-[#9945FF]" />
            <span className="font-bold text-lg">OnChainESign</span>
          </Link>
          {session ? (
            <Link href="/dashboard">
              <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white hover:bg-white/5">
                <ArrowLeft className="w-4 h-4 mr-1" /> Dashboard
              </Button>
            </Link>
          ) : (
            <Link href="/login">
              <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white hover:bg-white/5">Sign In</Button>
            </Link>
          )}
        </div>
      </header>

      <div className="max-w-5xl mx-auto px-4 py-16">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-3">Simple, <span className="gradient-text">Transparent</span> Pricing</h1>
          <p className="text-xl text-gray-400">The most affordable blockchain-verified e-signature platform</p>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {PLANS.map(plan => (
            <Card key={plan.planId} className={`relative overflow-hidden border-2 ${plan.borderColor} ${plan.popular ? 'shadow-xl shadow-[#9945FF]/10 scale-105' : ''}`}>
              {plan.popular && (
                <div className="absolute top-0 right-0 bg-gradient-to-r from-[#9945FF] to-[#14F195] text-white text-xs px-3 py-1 rounded-bl-lg font-medium">POPULAR</div>
              )}
              <CardHeader className="text-center pb-2">
                <div className="w-12 h-12 bg-white/5 rounded-full flex items-center justify-center mx-auto mb-3 text-[#9945FF]">
                  {plan.icon}
                </div>
                <CardTitle className="text-xl text-white">{plan.name}</CardTitle>
                <p className="text-gray-500 text-sm">{plan.desc}</p>
                <div className="mt-3">
                  <span className="text-4xl font-bold gradient-text">{plan.price}</span>
                  <span className="text-gray-500 text-sm">{plan.period}</span>
                </div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 mb-6">
                  {plan.features.map((f, i) => (
                    <li key={i} className="flex items-start gap-2 text-sm">
                      <Check className="w-4 h-4 text-[#14F195] flex-shrink-0 mt-0.5" />
                      <span className="text-gray-300">{f}</span>
                    </li>
                  ))}
                </ul>
                {userPlan === plan.planId ? (
                  <Button className="w-full" variant="secondary" disabled>Current Plan</Button>
                ) : plan.planId === 'enterprise' ? (
                  <Link href="mailto:sales@onchain-esign.app?subject=Enterprise%20Plan%20Inquiry">
                    <Button className="w-full" variant="outline">{plan.cta}</Button>
                  </Link>
                ) : plan.checkoutPlan ? (
                  <Link href={`/checkout?plan=${plan.checkoutPlan}`}>
                    <Button className="w-full">{plan.cta}</Button>
                  </Link>
                ) : (
                  <Button className="w-full" variant="secondary" disabled>{plan.cta}</Button>
                )}
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-12 text-center">
          <p className="text-gray-500 text-sm">All plans include Solana blockchain verification. Gas fees (~$0.001/doc) are separate.</p>
        </div>
      </div>
    </main>
  );
}
